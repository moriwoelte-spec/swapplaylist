package com.example.plsync

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

class MainActivity : Activity() {
    private val spRedirect = "ytsync://spotify"

    private var spTok: String? = null
    private var gTok: String? = null
    private var spVerifier = ""

    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var stSp: TextView
    private lateinit var stG: TextView
    private val prefs by lazy { getSharedPreferences("keys", MODE_PRIVATE) }
    private val bgColor = Color.parseColor("#0B0B2E")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f, m: Int = 0) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(m, m, m, m) }

    private fun pill(t: String, color: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(Color.parseColor(color)); cornerRadius = dp(28).toFloat() }
        setOnClickListener { f() }
    }

    private fun tile(name: String, kind: Int, c1: String, c2: String, txt: String, sub: TextView, f: () -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply { cornerRadius = dp(24).toFloat() }
            addView(LogoView(context, kind), LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(8) })
            addView(TextView(context).apply {
                text = name; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; setTextColor(Color.parseColor(txt))
            })
            sub.text = "Tippen zum Verbinden"; sub.textSize = 12f
            sub.gravity = Gravity.CENTER; sub.setTextColor(Color.parseColor(txt))
            addView(sub)
            setOnClickListener { f() }
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bgColor
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(48), dp(16), dp(24)) }
        root.addView(TextView(this).apply {
            text = "TuneSwap"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "Verbinde deine Musikdienste:"; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#B8B8D8")); setPadding(0, 0, 0, dp(20))
        })
        stSp = TextView(this); stG = TextView(this)
        val row = LinearLayout(this)
        row.addView(tile("Spotify", 0, "#FFFFFF", "#E6E6E6", "#1DB954", stSp) { loginSpotify() }, lp(0, dp(130), 1f, dp(6)))
        row.addView(tile("YouTube Music", 1, "#FF6B9A", "#D63D6E", "#FFFFFF", stG) { loginGoogle() }, lp(0, dp(130), 1f, dp(6)))
        root.addView(row)
        root.addView(TextView(this).apply {
            text = "Übertragen"; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(6), dp(24), 0, dp(6))
        })
        root.addView(pill("Spotify → YouTube Music", "#6C2BFF") { loadSpotifyLists() }, lp(MATCH, WRAP, 0f, dp(6)))
        root.addView(pill("YouTube Music → Spotify", "#6C2BFF") { loadYtLists() }, lp(MATCH, WRAP, 0f, dp(6)))
        root.addView(pill("⚙ Zugangsdaten (einmalig)", "#2A2A5E") { showKeys() }, lp(MATCH, WRAP, 0f, dp(6)))
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#B8B8D8")); setPadding(dp(6), dp(16), dp(6), dp(16)); setTextIsSelectable(true)
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(status)
        root.addView(list)
        setContentView(ScrollView(this).apply { setBackgroundColor(bgColor); addView(root) })
    }

    private fun showKeys() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        fun f(h: String, k: String) = EditText(this).apply {
            hint = h; isSingleLine = true; setText(prefs.getString(k, ""))
        }.also { box.addView(it) }
        val a = f("Spotify Client ID", "sp")
        val g = f("Google Client ID", "g")
        val c = f("Google Client Secret", "gs")
        AlertDialog.Builder(this).setTitle("Zugangsdaten (einmalig)").setView(box)
            .setPositiveButton("Speichern") { _, _ ->
                prefs.edit().putString("sp", a.text.toString().trim())
                    .putString("g", g.text.toString().trim()).putString("gs", c.text.toString().trim()).apply()
                log("Gespeichert ✓ – jetzt auf Spotify oder YouTube Music tippen")
            }.setNegativeButton("Abbrechen", null).show()
    }

    // ---------- Login ----------
    private fun verifier(): String {
        val b = ByteArray(48); SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
    private fun challenge(v: String) = Base64.encodeToString(
        MessageDigest.getInstance("SHA-256").digest(v.toByteArray()),
        Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun spId() = (prefs.getString("sp", "") ?: "").trim()

    private fun loginSpotify() {
        if (spId().isEmpty()) return showKeys()
        spVerifier = verifier()
        val u = "https://accounts.spotify.com/authorize?response_type=code&client_id=${spId()}" +
                "&redirect_uri=${enc(spRedirect)}&code_challenge_method=S256&code_challenge=${challenge(spVerifier)}" +
                "&scope=${enc("playlist-read-private playlist-modify-private playlist-modify-public")}"
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        val d = i.data ?: return
        val code = d.getQueryParameter("code") ?: return log("Login abgebrochen: ${d.getQueryParameter("error")}")
        bg {
            val r = http("POST", "https://accounts.spotify.com/api/token", null,
                "grant_type=authorization_code&code=${enc(code)}&redirect_uri=${enc(spRedirect)}" +
                        "&client_id=${spId()}&code_verifier=$spVerifier", true)
            spTok = r.getString("access_token")
            runOnUiThread { stSp.text = "Verbunden ✓" }
            log("Spotify verbunden ✓")
        }
    }

    // Google: Geräte-Login (Code auf google.com/device eingeben)
    private fun loginGoogle() {
        val gid = (prefs.getString("g", "") ?: "").trim(); val sec = (prefs.getString("gs", "") ?: "").trim()
        if (gid.isEmpty() || sec.isEmpty()) return showKeys()
        bg {
            val r = http("POST", "https://oauth2.googleapis.com/device/code", null,
                "client_id=${enc(gid)}&scope=${enc("https://www.googleapis.com/auth/youtube")}", true)
            val user = r.getString("user_code"); val dev = r.getString("device_code")
            val url = r.getString("verification_url"); var wait = r.optInt("interval", 5)
            runOnUiThread {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("code", user))
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
            log("Gib auf $url diesen Code ein:\n\n$user\n\n(Code ist kopiert.) Danach hierher zurück und kurz warten…")
            val end = System.currentTimeMillis() + r.optInt("expires_in", 1800) * 1000L
            while (System.currentTimeMillis() < end) {
                Thread.sleep(wait * 1000L)
                try {
                    val t = http("POST", "https://oauth2.googleapis.com/token", null,
                        "client_id=${enc(gid)}&client_secret=${enc(sec)}&device_code=${enc(dev)}" +
                                "&grant_type=${enc("urn:ietf:params:oauth:grant-type:device_code")}", true)
                    gTok = t.getString("access_token")
                    runOnUiThread { stG.text = "Verbunden ✓" }
                    log("YouTube verbunden ✓")
                    return@bg
                } catch (e: Exception) {
                    val m = e.message ?: ""
                    if (m.contains("slow_down")) wait += 5
                    else if (!m.contains("authorization_pending")) throw e
                }
            }
            log("Zeit abgelaufen, bitte nochmal versuchen")
        }
    }

    // ---------- Playlists anzeigen ----------
    private fun loadSpotifyLists() {
        val t = spTok ?: return log("Erst mit Spotify verbinden")
        bg {
            val items = http("GET", "https://api.spotify.com/v1/me/playlists?limit=50", t).getJSONArray("items")
            showLists(items, { it.getString("name") to it.getString("id") }) { id, name -> spToYt(id, name) }
        }
    }

    private fun loadYtLists() {
        val t = gTok ?: return log("Erst mit YouTube verbinden")
        bg {
            val items = http("GET", "https://www.googleapis.com/youtube/v3/playlists?part=snippet&mine=true&maxResults=50", t)
                .getJSONArray("items")
            showLists(items, { it.getJSONObject("snippet").getString("title") to it.getString("id") }) { id, name -> ytToSp(id, name) }
        }
    }

    private fun showLists(a: JSONArray, f: (JSONObject) -> Pair<String, String>, click: (String, String) -> Unit) {
        runOnUiThread {
            list.removeAllViews()
            for (i in 0 until a.length()) {
                val (name, id) = f(a.getJSONObject(i))
                list.addView(pill(name, "#2A2A5E") { click(id, name) }, lp(MATCH, WRAP, 0f, dp(4)))
            }
        }
    }

    // ---------- Spotify -> YouTube Music ----------
    private fun spToYt(id: String, name: String) {
        val s = spTok; val g = gTok
        if (s == null || g == null) return log("Beide Konten verbinden!")
        bg {
            val tracks = mutableListOf<String>()
            var url: String? = "https://api.spotify.com/v1/playlists/$id/tracks?limit=100"
            while (url != null) {
                val r = http("GET", url, s)
                val a = r.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val t = a.getJSONObject(i).optJSONObject("track") ?: continue
                    tracks += t.getString("name") + " " + t.getJSONArray("artists").getJSONObject(0).getString("name")
                }
                url = if (r.isNull("next")) null else r.getString("next")
            }
            log("${tracks.size} Songs gefunden. Erstelle YT-Playlist…")
            val pl = http("POST", "https://www.googleapis.com/youtube/v3/playlists?part=snippet,status", g,
                JSONObject().put("snippet", JSONObject().put("title", "$name (von Spotify)"))
                    .put("status", JSONObject().put("privacyStatus", "private")).toString()).getString("id")
            var ok = 0
            for ((n, q) in tracks.withIndex()) {
                try {
                    val items = http("GET", "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video" +
                            "&videoCategoryId=10&maxResults=1&q=${enc(q)}", g).getJSONArray("items")
                    if (items.length() == 0) { log("✗ nicht gefunden: $q"); continue }
                    val vid = items.getJSONObject(0).getJSONObject("id").getString("videoId")
                    http("POST", "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet", g,
                        JSONObject().put("snippet", JSONObject().put("playlistId", pl)
                            .put("resourceId", JSONObject().put("kind", "youtube#video").put("videoId", vid))).toString())
                    ok++; log("✓ ${n + 1}/${tracks.size}: $q")
                } catch (e: Exception) {
                    log("Abbruch bei '$q': ${e.message}\n(Evtl. YouTube-Tageslimit erreicht – morgen weitermachen)")
                    return@bg
                }
            }
            log("Fertig: $ok von ${tracks.size} übertragen.")
        }
    }

    // ---------- YouTube Music -> Spotify ----------
    private fun ytToSp(id: String, name: String) {
        val s = spTok; val g = gTok
        if (s == null || g == null) return log("Beide Konten verbinden!")
        bg {
            val queries = mutableListOf<String>()
            var page = ""
            do {
                val r = http("GET", "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50" +
                        "&playlistId=$id$page", g)
                val a = r.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val sn = a.getJSONObject(i).getJSONObject("snippet")
                    val title = sn.getString("title")
                    if (title == "Deleted video" || title == "Private video") continue
                    val clean = title.replace(Regex("\\(.*?\\)|\\[.*?]|(?i)official.*|(?i)ft\\..*|(?i)feat\\..*"), "").trim()
                    val artist = sn.optString("videoOwnerChannelTitle").removeSuffix(" - Topic")
                    queries += "$clean $artist"
                }
                page = if (r.has("nextPageToken")) "&pageToken=" + r.getString("nextPageToken") else ""
            } while (page.isNotEmpty())
            log("${queries.size} Songs gefunden. Suche bei Spotify…")
            val uris = mutableListOf<String>()
            for ((n, q) in queries.withIndex()) {
                val items = http("GET", "https://api.spotify.com/v1/search?type=track&limit=1&q=${enc(q)}", s)
                    .getJSONObject("tracks").getJSONArray("items")
                if (items.length() == 0) log("✗ nicht gefunden: $q")
                else { uris += items.getJSONObject(0).getString("uri"); log("✓ ${n + 1}/${queries.size}: $q") }
            }
            val pl = http("POST", "https://api.spotify.com/v1/me/playlists", s,
                JSONObject().put("name", "$name (von YT Music)").put("public", false).toString()).getString("id")
            uris.chunked(100).forEach {
                http("POST", "https://api.spotify.com/v1/playlists/$pl/tracks", s,
                    JSONObject().put("uris", JSONArray(it)).toString())
            }
            log("Fertig: ${uris.size} von ${queries.size} übertragen.")
        }
    }

    // ---------- Helfer ----------
    private fun bg(f: () -> Unit) = Thread {
        try { f() } catch (e: Exception) { log("Fehler: ${e.message}") }
    }.start()

    private fun log(m: String) = runOnUiThread { status.text = m }

    private fun http(method: String, url: String, token: String?, body: String? = null, form: Boolean = false): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", if (form) "application/x-www-form-urlencoded" else "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code >= 400) throw Exception("HTTP $code: ${text.take(200)}")
        return if (text.isBlank()) JSONObject() else JSONObject(text)
    }
}

class LogoView(c: Context, private val kind: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f
        p.style = Paint.Style.FILL
        if (kind == 0) {
            p.color = Color.parseColor("#1DB954"); cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeCap = Paint.Cap.ROUND
            fun arc(x1: Float, y1: Float, qx: Float, qy: Float, x2: Float, y2: Float, w: Float) {
                p.strokeWidth = w * r
                cv.drawPath(Path().apply { moveTo(cx + x1 * r, cy + y1 * r); quadTo(cx + qx * r, cy + qy * r, cx + x2 * r, cy + y2 * r) }, p)
            }
            arc(-0.55f, -0.28f, 0.05f, -0.52f, 0.55f, -0.12f, 0.15f)
            arc(-0.45f, 0.02f, 0.05f, -0.18f, 0.45f, 0.12f, 0.12f)
            arc(-0.35f, 0.30f, 0.05f, 0.15f, 0.35f, 0.35f, 0.10f)
        } else {
            p.color = Color.parseColor("#F0453A"); cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 0.09f * r
            cv.drawCircle(cx, cy, 0.62f * r, p)
            p.style = Paint.Style.FILL
            cv.drawPath(Path().apply {
                moveTo(cx - 0.18f * r, cy - 0.3f * r); lineTo(cx - 0.18f * r, cy + 0.3f * r)
                lineTo(cx + 0.32f * r, cy); close()
            }, p)
        }
    }
}
