TuneSwap – Playlists zwischen Spotify und YouTube Music übertragen

So wird gebaut
- Diese Datei (TuneSwap.zip) liegt im Hauptordner des GitHub-Repos.
- Actions > "Build APK" > "Run workflow". Danach die APK unter "Releases" holen.

Anmelden (keine API, keine Schlüssel nötig)
- Kachel antippen, die Anmeldeseite des Dienstes geht in der App auf, normal anmelden.
- Spotify: Die App liest den Zugangsschlüssel aus dem Spotify-Web-Player mit.
- YouTube Music: Die App nutzt deine Anmeldung auf music.youtube.com.
- Beides sind inoffizielle Wege und können brechen, wenn Spotify oder Google etwas ändern.

Optional, falls Spotify per Web-Login nicht klappt (offizieller Weg)
- developer.spotify.com/dashboard > Create app (Premium nötig), Redirect URI: ytsync://spotify
- Client ID als GitHub-Secret SPOTIFY_ID anlegen, neu bauen. Dann nutzt die App den offiziellen Login.

Neu in Version 1.2
- Startseite wie im Vorbild: "Quelldienst auswählen" mit Suchfeld, Kachelraster aller Musikdienste und unterer Leiste
  (Startseite, Übertragung, Autom Sync, Profil, Premium).
- Antippen einer Kachel öffnet die Anmeldung auf der Website des Dienstes (auch Spotify, Apple Music usw.).
  Es werden dabei keine Songs oder Playlists mehr geladen. Bei Diensten außer Spotify und YouTube Music
  tippst du nach dem Anmelden oben rechts auf "Fertig"; dann zeigt die Kachel "Verbunden".
- Playlists übertragen: unten auf "Übertragung" tippen (Spotify <-> YouTube Music; andere Dienste folgen).
- Profil = alle Verbindungen trennen. Autom Sync und Premium sind noch Platzhalter.

Neu in Version 1.1
- Anmeldung bleibt gespeichert: Nach dem Neustart sind Spotify und YouTube Music weiter verbunden.
  Der Spotify-Schlüssel wird bei Bedarf automatisch im Hintergrund erneuert.
- Unten auf "Profil" tippen = Dienste abmelden.
- Nach der Anmeldung wird "Verbunden" angezeigt. Die Playlists öffnest du über "Übertragung"
  (eigener Bildschirm mit Suche und "Alle auswählen").
- Spotify wird nicht mehr mit Anfragen überflutet (HTTP 429): gleichmäßiges Tempo, automatische Pause bei Spotify-Bremse.
- Nach "Übertragen" werden alle Lieder zuerst abgeglichen (mehrere gleichzeitig, deutlich schneller).
  Fortschrittsleiste oben zeigt den Song, der gerade gesucht wird, später das Hinzufügen.
- Überprüfungs-Bildschirm: Nicht gefundene Lieder lassen sich ignorieren oder erneut abgleichen,
  darunter stehen alle Lieder, die hinzugefügt werden. Erst "Übereinstimmungen bestätigen" legt die Playlist an.
- Die Lieder werden nacheinander gesucht. Künstler und Länge zählen mit, damit die richtige Version gewählt wird;
  bei gefundenen Liedern steht der Treffer (Titel · Künstler) in grün unter dem Lied.
- Oben im Dienst-Bildschirm gibt es Reiter: Wiedergabelisten, Alben, Lieder, Künstler.
  Alben/Lieder/Künstler werden wie Playlists abgeglichen, geprüft und danach in die Bibliothek des anderen Dienstes
  übernommen (Album speichern, Lied liken, Künstler folgen). Diese Teile nutzen inoffizielle Schnittstellen und sind ungetestet.
