package com.example.plsync

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

// Ein Musikdienst auf der Startseite (Reihenfolge wie im Vorbild)
class Svc(
    val id: String,
    val name: String,
    val c1: String,                 // Kachel: Farbe oben
    val c2: String,                 // Kachel: Farbe unten
    val txt: String,                // Farbe der Beschriftung
    val url: String = "",           // Anmeldeseite (Website des Dienstes)
    val desktop: Boolean = false,   // Desktop-Browser-Kennung verwenden
    val lw: Int = 34,               // Breite des Logos in dp
    val lh: Int = 34,               // Höhe des Logos in dp
    val label: Boolean = true,      // Name unter dem Logo anzeigen?
    val askUrl: Boolean = false,    // Adresse beim Nutzer abfragen (Navidrome = eigener Server)
    val diag: Boolean = false       // Farbverlauf schräg statt senkrecht
)

val SERVICES: List<Svc> = listOf(
    Svc("spotify", "Spotify", "#FFFFFF", "#E6E6E6", "#1DB954"),
    Svc("applemusic", "Apple Music", "#FFFFFF", "#E6E6E6", "#000000",
        "https://music.apple.com/de/browse", desktop = true),
    Svc("amazonmusic", "Amazon Music", "#FFFFFF", "#FFFFFF", "#000000",
        "https://music.amazon.de/", desktop = true, lw = 48, lh = 29),
    Svc("youtube", "YouTube", "#FF1A1A", "#B00D0D", "#FFFFFF",
        "https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F"),
    Svc("ytmusic", "YouTube Music", "#FF6B9A", "#D63D6E", "#FFFFFF"),
    Svc("soundcloud", "SoundCloud", "#FF6B2C", "#E5531F", "#FFFFFF", "https://soundcloud.com/"),
    Svc("deezer", "Deezer", "#3B3B80", "#34346F", "#FFFFFF", "https://www.deezer.com/login", lw = 118, lh = 36),
    Svc("tidal", "Tidal", "#2F3444", "#2F3444", "#FFFFFF", "https://listen.tidal.com/login", desktop = true),
    Svc("discogs", "Discogs", "#333333", "#333333", "#FFFFFF", "https://www.discogs.com/login", lw = 100, lh = 36),
    Svc("qobuz", "Qobuz", "#0080FF", "#0080FF", "#FFFFFF", "https://play.qobuz.com/login", desktop = true),
    Svc("pandora", "Pandora", "#FFFFFF", "#E8E8E8", "#3668FF",
        "https://www.pandora.com/account/sign-in", desktop = true),
    Svc("anghami", "Anghami", "#8A1FD1", "#7A15C2", "#FFFFFF", "https://play.anghami.com/"),
    Svc("qqmusic", "QQ music", "#FFFFFF", "#FFFFFF", "#17A34A", "https://y.qq.com/"),
    Svc("audius", "Audius", "#000000", "#000000", "#FFFFFF", "https://audius.co/"),
    Svc("navervibe", "NaverVibe", "#FF0A33", "#8A00FF", "#FFFFFF",
        "https://nid.naver.com/nidlogin.login?url=https%3A%2F%2Fvibe.naver.com%2F", diag = true),
    Svc("iheart", "iHeartRadio", "#4A0E10", "#3A0A0C", "#FFFFFF", "https://www.iheart.com/",
        lw = 134, lh = 52, label = false),
    Svc("melon", "Melon", "#FFFFFF", "#FFFFFF", "#000000", "https://www.melon.com/", lw = 86, lh = 34),
    Svc("jiosaavn", "JioSaavn", "#3C4050", "#2B2E3A", "#FFFFFF", "https://www.jiosaavn.com/"),
    Svc("virtualdj", "Virtual dj", "#2A2A2E", "#242428", "#FFFFFF", "https://www.virtualdj.com/"),
    Svc("lastfm", "Last.fm", "#FFFFFF", "#FFFFFF", "#D51007", "https://www.last.fm/login"),
    Svc("beatport", "Beatport", "#01FF95", "#00F58C", "#000000", "https://www.beatport.com/account/login"),
    Svc("napster", "Napster", "#FFFFFF", "#FFFFFF", "#1F6FDE", "https://app.napster.com/login/", desktop = true),
    Svc("beatsource", "Beatsource", "#0078D7", "#0068BF", "#FFFFFF", "https://www.beatsource.com/"),
    Svc("boomplay", "Boomplay", "#00F0F0", "#00E6E8", "#000000", "https://www.boomplay.com/"),
    Svc("bandcamp", "Bandcamp", "#FFFFFF", "#FFFFFF", "#000000", "https://bandcamp.com/login"),
    Svc("gaana", "Gaana", "#E72C30", "#E72C30", "#FFFFFF", "https://gaana.com/"),
    Svc("mixcloud", "Mixcloud", "#272B45", "#222640", "#FFFFFF", "https://www.mixcloud.com/"),
    Svc("trebel", "Trebel", "#FFF200", "#FFF200", "#000000", "https://www.trebelmusic.com/",
        lw = 90, lh = 34, label = false),
    Svc("navidrome", "Navidrome", "#FFFFFF", "#FFFFFF", "#000000", askUrl = true),
    Svc("audiomack", "Audiomack", "#0D0D0D", "#0D0D0D", "#FFFFFF", "https://audiomack.com/login"),
    Svc("lyra", "LYRA", "#0A2B1D", "#08201A", "#FFFFFF", "https://lyramusic.app/",
        lw = 70, lh = 64, label = false),
    Svc("bugs", "Bugs!", "#FF4136", "#FF4136", "#FFFFFF", "https://music.bugs.co.kr/",
        lw = 130, lh = 56, label = false),
    Svc("ibroadcast", "iBroadcast", "#333333", "#2B2B2B", "#FFFFFF", "https://media.ibroadcast.com/"),
    Svc("mixerbox", "MixerBox MB3", "#2FAEDC", "#2FAEDC", "#FFFFFF", "https://www.mixerbox.com/"),
    Svc("shazam", "Shazam", "#2563FF", "#1A55F0", "#FFFFFF", "https://www.shazam.com/"),
    Svc("vkmusic", "VK Music", "#0077FF", "#0077FF", "#FFFFFF", "https://vk.com/")
)

// Vereinfachte Logos der Dienste (selbst gezeichnet, keine Bilddateien nötig)
class BrandView(c: Context, private val key: String) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var w = 0f
    private var h = 0f
    private var s = 0f
    private var ox = 0f
    private var oy = 0f

    private fun px(v: Float) = ox + v * s
    private fun py(v: Float) = oy + v * s

    private fun fill(col: String) { p.style = Paint.Style.FILL; p.color = Color.parseColor(col) }

    private fun line(col: String, wd: Float) {
        p.style = Paint.Style.STROKE; p.color = Color.parseColor(col)
        p.strokeWidth = wd * s; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
    }

    private fun circle(cv: Canvas, cx: Float, cy: Float, r: Float) { cv.drawCircle(px(cx), py(cy), r * s, p) }

    private fun rect(cv: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float) {
        cv.drawRoundRect(RectF(px(l), py(t), px(r), py(b)), rad * s, rad * s, p)
    }

    private fun oval(cv: Canvas, l: Float, t: Float, r: Float, b: Float) {
        cv.drawOval(RectF(px(l), py(t), px(r), py(b)), p)
    }

    private fun seg(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        cv.drawLine(px(x1), py(y1), px(x2), py(y2), p)
    }

    private fun poly(cv: Canvas, vararg pts: Float) {
        val pa = Path()
        var i = 0
        while (i + 1 < pts.size) {
            if (i == 0) pa.moveTo(px(pts[0]), py(pts[1])) else pa.lineTo(px(pts[i]), py(pts[i + 1]))
            i += 2
        }
        pa.close()
        cv.drawPath(pa, p)
    }

    private fun text(cv: Canvas, t: String, cx: Float, cy: Float, size: Float, col: String, tf: Typeface) {
        p.style = Paint.Style.FILL; p.color = Color.parseColor(col)
        p.textSize = size * s; p.typeface = tf; p.textAlign = Paint.Align.CENTER
        cv.drawText(t, px(cx), py(cy) - (p.ascent() + p.descent()) / 2f, p)
    }

    // Text mittig in der ganzen Fläche (für Wortmarken)
    private fun wordmark(cv: Canvas, t: String, size: Float, col: String, tf: Typeface) {
        p.style = Paint.Style.FILL; p.color = Color.parseColor(col)
        p.textSize = size * h; p.typeface = tf; p.textAlign = Paint.Align.CENTER
        cv.drawText(t, w / 2f, h / 2f - (p.ascent() + p.descent()) / 2f, p)
    }

    override fun onDraw(cv: Canvas) {
        w = width.toFloat(); h = height.toFloat()
        s = minOf(w, h); ox = (w - s) / 2f; oy = (h - s) / 2f
        when (key) {
            "spotify" -> {
                fill("#1DB954"); circle(cv, 0.5f, 0.5f, 0.5f)
                fun arc(x1: Float, y1: Float, qx: Float, qy: Float, x2: Float, y2: Float, wd: Float) {
                    line("#FFFFFF", wd)
                    val pa = Path()
                    pa.moveTo(px(0.5f + x1 * 0.5f), py(0.5f + y1 * 0.5f))
                    pa.quadTo(px(0.5f + qx * 0.5f), py(0.5f + qy * 0.5f), px(0.5f + x2 * 0.5f), py(0.5f + y2 * 0.5f))
                    cv.drawPath(pa, p)
                }
                arc(-0.55f, -0.28f, 0.05f, -0.52f, 0.55f, -0.12f, 0.075f)
                arc(-0.45f, 0.02f, 0.05f, -0.18f, 0.45f, 0.12f, 0.06f)
                arc(-0.35f, 0.30f, 0.05f, 0.15f, 0.35f, 0.35f, 0.05f)
            }
            "ytmusic" -> {
                fill("#F0453A"); circle(cv, 0.5f, 0.5f, 0.5f)
                line("#FFFFFF", 0.045f); circle(cv, 0.5f, 0.5f, 0.31f)
                fill("#FFFFFF"); poly(cv, 0.41f, 0.35f, 0.41f, 0.65f, 0.66f, 0.50f)
            }
            "applemusic" -> {
                val body = Path()
                body.addCircle(px(0.36f), py(0.60f), 0.27f * s, Path.Direction.CW)
                body.addCircle(px(0.64f), py(0.60f), 0.27f * s, Path.Direction.CW)
                val bite = Path()
                bite.addCircle(px(0.90f), py(0.48f), 0.17f * s, Path.Direction.CW)
                body.op(bite, Path.Op.DIFFERENCE)
                fill("#000000"); cv.drawPath(body, p)
                val leaf = Path()
                leaf.addOval(RectF(px(0.50f), py(0.04f), px(0.72f), py(0.24f)), Path.Direction.CW)
                val m = Matrix(); m.postRotate(-35f, px(0.61f), py(0.14f)); leaf.transform(m)
                cv.drawPath(leaf, p)
            }
            "amazonmusic" -> {
                fill("#111111"); cv.drawRoundRect(RectF(0f, 0f, w, h), 0.2f * h, 0.2f * h, p)
                p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.DEFAULT_BOLD; p.textSize = 0.30f * h
                cv.drawText("amazon", w / 2f, 0.44f * h, p)
                p.typeface = Typeface.DEFAULT; p.textSize = 0.34f * h
                cv.drawText("music", w / 2f, 0.82f * h, p)
            }
            "youtube" -> {
                fill("#FF3B30"); rect(cv, 0.0f, 0.15f, 1.0f, 0.85f, 0.22f)
                fill("#FFFFFF"); poly(cv, 0.40f, 0.33f, 0.40f, 0.67f, 0.69f, 0.50f)
            }
            "soundcloud" -> {
                val cloud = Path()
                cloud.addCircle(px(0.60f), py(0.60f), 0.15f * s, Path.Direction.CW)
                cloud.addCircle(px(0.78f), py(0.50f), 0.20f * s, Path.Direction.CW)
                cloud.addRect(px(0.52f), py(0.58f), px(0.96f), py(0.76f), Path.Direction.CW)
                fill("#FFFFFF"); cv.drawPath(cloud, p)
                line("#FFFFFF", 0.06f)
                val xs = floatArrayOf(0.06f, 0.15f, 0.24f, 0.33f, 0.42f)
                val tops = floatArrayOf(0.60f, 0.50f, 0.42f, 0.38f, 0.40f)
                for (i in xs.indices) seg(cv, xs[i], tops[i], xs[i], 0.76f)
            }
            "deezer" -> {
                p.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL); p.textSize = 0.54f * h
                val tw = p.measureText("DEEZER")
                val iw = 0.92f * h
                val start = (w - (iw + 0.16f * h + tw)) / 2f
                val step = iw / 7f
                val bh = floatArrayOf(0.42f, 0.68f, 0.88f, 1.0f, 0.88f, 0.68f, 0.42f)
                fill("#A238FF")
                for (i in 0 until 7) {
                    val bhh = bh[i] * 0.86f * h
                    val l = start + i * step
                    cv.drawRoundRect(RectF(l, h / 2f - bhh / 2f, l + step * 0.64f, h / 2f + bhh / 2f),
                        step * 0.3f, step * 0.3f, p)
                }
                p.color = Color.WHITE; p.textAlign = Paint.Align.LEFT
                cv.drawText("DEEZER", start + iw + 0.16f * h, h / 2f - (p.ascent() + p.descent()) / 2f, p)
            }
            "tidal" -> {
                fill("#FFFFFF")
                fun d(cx: Float, cy: Float, r: Float) = poly(cv, cx, cy - r, cx + r, cy, cx, cy + r, cx - r, cy)
                d(0.20f, 0.36f, 0.16f); d(0.50f, 0.36f, 0.16f); d(0.80f, 0.36f, 0.16f); d(0.50f, 0.66f, 0.16f)
            }
            "discogs" -> wordmark(cv, "Discogs", 0.82f, "#FFFFFF", Typeface.create("sans-serif-condensed", Typeface.BOLD))
            "qobuz" -> {
                fill("#FFFFFF"); circle(cv, 0.47f, 0.47f, 0.42f)
                fill("#000000"); circle(cv, 0.47f, 0.47f, 0.32f)
                line("#FFFFFF", 0.07f); circle(cv, 0.47f, 0.47f, 0.17f)
                fill("#FFFFFF"); circle(cv, 0.47f, 0.47f, 0.06f)
                line("#FFFFFF", 0.12f); seg(cv, 0.70f, 0.70f, 0.90f, 0.90f)
            }
            "pandora" -> text(cv, "P", 0.5f, 0.52f, 1.05f, "#3668FF", Typeface.create(Typeface.SERIF, Typeface.BOLD))
            "anghami" -> {
                val cols = arrayOf("#E5F000", "#13D68C", "#14B8FF", "#FF2DAA")
                for (i in 0 until 4) { line(cols[i], 0.075f); circle(cv, 0.46f, 0.50f, 0.40f - i * 0.085f) }
                line("#E5F000", 0.08f); seg(cv, 0.86f, 0.20f, 0.86f, 0.86f)
            }
            "qqmusic" -> {
                fill("#FFD500"); circle(cv, 0.5f, 0.5f, 0.5f)
                fill("#0DA84A"); oval(cv, 0.24f, 0.58f, 0.54f, 0.84f)
                line("#0DA84A", 0.1f); seg(cv, 0.50f, 0.72f, 0.50f, 0.20f)
                val fl = Path()
                fl.moveTo(px(0.50f), py(0.20f)); fl.quadTo(px(0.80f), py(0.28f), px(0.74f), py(0.52f))
                cv.drawPath(fl, p)
            }
            "audius" -> {
                fill("#FFFFFF"); poly(cv, 0.50f, 0.10f, 0.92f, 0.86f, 0.08f, 0.86f)
                fill("#000000"); poly(cv, 0.50f, 0.56f, 0.64f, 0.86f, 0.36f, 0.86f)
            }
            "navervibe" -> {
                fill("#FFFFFF")
                val bh = floatArrayOf(0.35f, 0.60f, 0.45f, 0.85f, 0.50f, 0.65f, 0.30f)
                for (i in 0 until 7) {
                    val cx = 0.14f + i * 0.12f
                    rect(cv, cx - 0.035f, 0.5f - bh[i] / 2f, cx + 0.035f, 0.5f + bh[i] / 2f, 0.035f)
                }
            }
            "iheart" -> {
                val hs = 0.80f * h
                val hx = w * 0.04f
                val hy = h * 0.12f
                val heart = Path()
                heart.moveTo(hx + hs / 2f, hy + hs)
                heart.cubicTo(hx - hs * 0.25f, hy + hs * 0.55f, hx + hs * 0.05f, hy - hs * 0.15f, hx + hs / 2f, hy + hs * 0.25f)
                heart.cubicTo(hx + hs * 0.95f, hy - hs * 0.15f, hx + hs * 1.25f, hy + hs * 0.55f, hx + hs / 2f, hy + hs)
                heart.close()
                fill("#E4002B"); cv.drawPath(heart, p)
                fill("#FFFFFF"); cv.drawCircle(hx + hs / 2f, hy + hs * 0.44f, hs * 0.09f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = hs * 0.06f; p.strokeCap = Paint.Cap.ROUND
                val ccx = hx + hs / 2f; val ccy = hy + hs * 0.44f
                cv.drawArc(RectF(ccx - hs * 0.22f, ccy - hs * 0.22f, ccx + hs * 0.22f, ccy + hs * 0.22f), 200f, 140f, false, p)
                cv.drawArc(RectF(ccx - hs * 0.34f, ccy - hs * 0.34f, ccx + hs * 0.34f, ccy + hs * 0.34f), 210f, 120f, false, p)
                val tx = hx + hs * 1.22f
                p.style = Paint.Style.FILL; p.textAlign = Paint.Align.LEFT
                p.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL); p.textSize = 0.42f * h
                p.color = Color.WHITE; cv.drawText("iHeart", tx, h * 0.52f, p)
                p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                p.color = Color.parseColor("#C9B8B8"); cv.drawText("RADIO", tx, h * 0.92f, p)
            }
            "melon" -> wordmark(cv, "Melon", 0.85f, "#00CD3C", Typeface.DEFAULT_BOLD)
            "jiosaavn" -> {
                line("#FFFFFF", 0.05f); rect(cv, 0.30f, 0.22f, 0.94f, 0.86f, 0.12f)
                text(cv, "S", 0.62f, 0.56f, 0.40f, "#FFFFFF", Typeface.DEFAULT_BOLD)
                fill("#2EC4B6"); circle(cv, 0.27f, 0.30f, 0.24f)
                text(cv, "Jio", 0.27f, 0.30f, 0.20f, "#FFFFFF", Typeface.DEFAULT_BOLD)
            }
            "virtualdj" -> {
                fill("#101010"); circle(cv, 0.5f, 0.60f, 0.34f)
                line("#555555", 0.025f); circle(cv, 0.5f, 0.60f, 0.26f); circle(cv, 0.5f, 0.60f, 0.18f)
                fill("#E02020"); circle(cv, 0.5f, 0.60f, 0.07f)
                val hand = Path()
                hand.moveTo(px(0.38f), py(0.36f)); hand.quadTo(px(0.55f), py(0.05f), px(0.82f), py(0.14f))
                hand.quadTo(px(0.70f), py(0.30f), px(0.60f), py(0.40f)); hand.close()
                cv.drawPath(hand, p)
            }
            "lastfm" -> text(cv, "as", 0.5f, 0.55f, 1.05f, "#D51007", Typeface.create("sans-serif-black", Typeface.NORMAL))
            "beatport" -> {
                line("#000000", 0.14f); circle(cv, 0.58f, 0.62f, 0.22f)
                seg(cv, 0.40f, 0.10f, 0.34f, 0.82f)
            }
            "napster" -> {
                fill("#1F6FDE"); circle(cv, 0.5f, 0.56f, 0.38f)
                poly(cv, 0.15f, 0.42f, 0.12f, 0.08f, 0.40f, 0.22f)
                poly(cv, 0.85f, 0.42f, 0.88f, 0.08f, 0.60f, 0.22f)
                fill("#FFFFFF"); oval(cv, 0.28f, 0.40f, 0.72f, 0.78f)
                fill("#7ED321"); oval(cv, 0.34f, 0.48f, 0.46f, 0.58f); oval(cv, 0.54f, 0.48f, 0.66f, 0.58f)
                oval(cv, 0.43f, 0.64f, 0.57f, 0.70f)
            }
            "beatsource" -> {
                fill("#FFFFFF"); rect(cv, 0.22f, 0.10f, 0.42f, 0.90f, 0.02f)
                cv.drawArc(RectF(px(0.22f), py(0.36f), px(0.84f), py(0.90f)), -90f, 180f, true, p)
            }
            "boomplay" -> {
                fill("#050505"); circle(cv, 0.5f, 0.5f, 0.5f)
                line("#FFFFFF", 0.04f); circle(cv, 0.5f, 0.5f, 0.45f)
                text(cv, "B", 0.5f, 0.52f, 0.62f, "#2CC8FF", Typeface.DEFAULT_BOLD)
            }
            "bandcamp" -> {
                fill("#1DA0C3"); poly(cv, 0.0f, 0.78f, 0.30f, 0.22f, 1.0f, 0.22f, 0.70f, 0.78f)
            }
            "gaana" -> text(cv, "g", 0.5f, 0.50f, 1.15f, "#FFFFFF", Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC))
            "mixcloud" -> {
                val a = Path(); a.addCircle(px(0.34f), py(0.58f), 0.17f * s, Path.Direction.CW)
                val b = Path(); b.addCircle(px(0.52f), py(0.44f), 0.21f * s, Path.Direction.CW)
                val r = Path(); r.addRect(px(0.34f), py(0.58f), px(0.66f), py(0.75f), Path.Direction.CW)
                val u = Path(a); u.op(b, Path.Op.UNION); u.op(r, Path.Op.UNION)
                line("#F2A8A8", 0.06f); cv.drawPath(u, p)
                cv.drawArc(RectF(px(0.58f), py(0.42f), px(0.84f), py(0.72f)), -50f, 100f, false, p)
                cv.drawArc(RectF(px(0.58f), py(0.32f), px(0.96f), py(0.82f)), -50f, 100f, false, p)
            }
            "trebel" -> {
                p.style = Paint.Style.STROKE; p.color = Color.BLACK; p.strokeWidth = 0.09f * h
                cv.drawRect(RectF(0.05f * h, 0.12f * h, w - 0.05f * h, 0.88f * h), p)
                wordmark(cv, "TREBEL", 0.50f, "#000000", Typeface.create("sans-serif-black", Typeface.NORMAL))
            }
            "navidrome" -> {
                fill("#0A84FF"); circle(cv, 0.5f, 0.5f, 0.46f)
                line("#000000", 0.05f); circle(cv, 0.5f, 0.5f, 0.46f); circle(cv, 0.5f, 0.5f, 0.32f); circle(cv, 0.5f, 0.5f, 0.20f)
                fill("#FFFFFF"); circle(cv, 0.5f, 0.5f, 0.12f)
                fill("#000000"); circle(cv, 0.5f, 0.5f, 0.045f)
            }
            "audiomack" -> {
                val pts = floatArrayOf(0.04f, 0.52f, 0.28f, 0.52f, 0.40f, 0.20f, 0.52f, 0.82f,
                    0.64f, 0.12f, 0.76f, 0.72f, 0.86f, 0.44f, 0.98f, 0.44f)
                val pa = Path()
                pa.moveTo(px(pts[0]), py(pts[1]))
                var i = 2
                while (i + 1 < pts.size) { pa.lineTo(px(pts[i]), py(pts[i + 1])); i += 2 }
                line("#FF9F0A", 0.09f); cv.drawPath(pa, p)
            }
            "lyra" -> {
                val leaf = Path()
                leaf.moveTo(0.52f * w, 0.02f * h)
                leaf.cubicTo(0.88f * w, 0.14f * h, 0.92f * w, 0.52f * h, 0.62f * w, 0.62f * h)
                leaf.cubicTo(0.40f * w, 0.70f * h, 0.14f * w, 0.60f * h, 0.20f * w, 0.36f * h)
                leaf.cubicTo(0.26f * w, 0.18f * h, 0.42f * w, 0.30f * h, 0.52f * w, 0.02f * h)
                leaf.close()
                fill("#2FD65F"); cv.drawPath(leaf, p)
                p.color = Color.WHITE; p.typeface = Typeface.DEFAULT_BOLD
                p.textAlign = Paint.Align.CENTER; p.textSize = 0.34f * h
                cv.drawText("LYRA", w / 2f, 0.97f * h, p)
            }
            "bugs" -> wordmark(cv, "Bugs!", 0.80f, "#FFFFFF", Typeface.create("sans-serif-black", Typeface.ITALIC))
            "ibroadcast" -> text(cv, "iB", 0.5f, 0.52f, 1.0f, "#FFFFFF", Typeface.DEFAULT_BOLD)
            "mixerbox" -> {
                fill("#FFFFFF"); oval(cv, 0.10f, 0.62f, 0.34f, 0.84f); oval(cv, 0.58f, 0.50f, 0.82f, 0.72f)
                line("#FFFFFF", 0.08f)
                seg(cv, 0.32f, 0.72f, 0.32f, 0.26f); seg(cv, 0.80f, 0.60f, 0.80f, 0.14f); seg(cv, 0.32f, 0.28f, 0.80f, 0.16f)
            }
            "shazam" -> {
                fill("#3D8BFF"); circle(cv, 0.5f, 0.5f, 0.5f)
                text(cv, "S", 0.5f, 0.52f, 0.78f, "#FFFFFF", Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD))
            }
            "vkmusic" -> text(cv, "VK", 0.5f, 0.52f, 0.78f, "#FFFFFF", Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC))
            else -> {
                fill("#FFFFFF"); circle(cv, 0.5f, 0.5f, 0.5f)
                text(cv, key.take(1).uppercase(), 0.5f, 0.52f, 0.6f, "#000000", Typeface.DEFAULT_BOLD)
            }
        }
    }
}

// Kleine Linien-Symbole für Kopfzeile und Navigationsleiste
class IconView(c: Context, private val kind: String) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var col: Int = Color.WHITE
        set(v) { field = v; invalidate() }

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        fun px(v: Float) = ox + v * s
        fun py(v: Float) = oy + v * s
        p.style = Paint.Style.STROKE; p.color = col
        p.strokeWidth = 0.08f * s; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        val pa = Path()
        when (kind) {
            "bell" -> {
                pa.moveTo(px(0.20f), py(0.74f))
                pa.quadTo(px(0.30f), py(0.66f), px(0.30f), py(0.46f))
                pa.cubicTo(px(0.30f), py(0.26f), px(0.40f), py(0.18f), px(0.50f), py(0.18f))
                pa.cubicTo(px(0.60f), py(0.18f), px(0.70f), py(0.26f), px(0.70f), py(0.46f))
                pa.quadTo(px(0.70f), py(0.66f), px(0.80f), py(0.74f))
                pa.close()
                cv.drawPath(pa, p)
                cv.drawArc(RectF(px(0.42f), py(0.70f), px(0.58f), py(0.90f)), 20f, 140f, false, p)
                cv.drawLine(px(0.5f), py(0.10f), px(0.5f), py(0.18f), p)
            }
            "search" -> {
                cv.drawCircle(px(0.44f), py(0.44f), 0.26f * s, p)
                cv.drawLine(px(0.63f), py(0.63f), px(0.86f), py(0.86f), p)
            }
            "home" -> {
                pa.moveTo(px(0.10f), py(0.50f)); pa.lineTo(px(0.50f), py(0.14f)); pa.lineTo(px(0.90f), py(0.50f))
                cv.drawPath(pa, p)
                val b = Path()
                b.moveTo(px(0.22f), py(0.42f)); b.lineTo(px(0.22f), py(0.84f))
                b.lineTo(px(0.78f), py(0.84f)); b.lineTo(px(0.78f), py(0.42f))
                cv.drawPath(b, p)
                val d = Path()
                d.moveTo(px(0.42f), py(0.84f)); d.lineTo(px(0.42f), py(0.66f))
                d.quadTo(px(0.50f), py(0.56f), px(0.58f), py(0.66f)); d.lineTo(px(0.58f), py(0.84f))
                cv.drawPath(d, p)
            }
            "swap" -> {
                cv.drawLine(px(0.14f), py(0.32f), px(0.86f), py(0.32f), p)
                cv.drawLine(px(0.70f), py(0.18f), px(0.86f), py(0.32f), p)
                cv.drawLine(px(0.70f), py(0.46f), px(0.86f), py(0.32f), p)
                cv.drawLine(px(0.86f), py(0.68f), px(0.14f), py(0.68f), p)
                cv.drawLine(px(0.30f), py(0.54f), px(0.14f), py(0.68f), p)
                cv.drawLine(px(0.30f), py(0.82f), px(0.14f), py(0.68f), p)
            }
            "sync" -> {
                val r = 0.34f * s
                val cx = px(0.5f); val cy = py(0.5f)
                val box = RectF(cx - r, cy - r, cx + r, cy + r)
                cv.drawArc(box, 200f, 130f, false, p)
                cv.drawArc(box, 20f, 130f, false, p)
                for (a0 in floatArrayOf(330f, 150f)) {
                    val rad = Math.toRadians(a0.toDouble())
                    val nx = Math.cos(rad).toFloat(); val ny = Math.sin(rad).toFloat()
                    val ex = cx + r * nx; val ey = cy + r * ny
                    val tx = -ny; val ty = nx
                    val l = 0.18f * s
                    cv.drawLine(ex, ey, ex - tx * l + nx * l * 0.6f, ey - ty * l + ny * l * 0.6f, p)
                    cv.drawLine(ex, ey, ex - tx * l - nx * l * 0.6f, ey - ty * l - ny * l * 0.6f, p)
                }
            }
            "person" -> {
                cv.drawCircle(px(0.5f), py(0.32f), 0.17f * s, p)
                cv.drawArc(RectF(px(0.18f), py(0.56f), px(0.82f), py(1.20f)), 180f, 180f, false, p)
            }
            "diamond" -> {
                pa.moveTo(px(0.28f), py(0.22f)); pa.lineTo(px(0.72f), py(0.22f)); pa.lineTo(px(0.90f), py(0.42f))
                pa.lineTo(px(0.50f), py(0.86f)); pa.lineTo(px(0.10f), py(0.42f)); pa.close()
                cv.drawPath(pa, p)
                cv.drawLine(px(0.10f), py(0.42f), px(0.90f), py(0.42f), p)
                val g = Path()
                g.moveTo(px(0.38f), py(0.22f)); g.lineTo(px(0.30f), py(0.42f)); g.lineTo(px(0.50f), py(0.86f))
                g.moveTo(px(0.62f), py(0.22f)); g.lineTo(px(0.70f), py(0.42f)); g.lineTo(px(0.50f), py(0.86f))
                cv.drawPath(g, p)
            }
        }
    }
}
