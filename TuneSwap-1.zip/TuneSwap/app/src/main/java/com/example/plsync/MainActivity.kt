package com.example.plsync

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class PL(val id: String, val name: String, val count: Int, val img: String?)

class MainActivity : Activity() {
    private val spRedirect = "ytsync://spotify"
    @Volatile private var spTok: String? = null
    @Volatile private var ytCookie: String? = null
    private var ytUa = ""
    private var spVerifier = ""
    private var src = ""
    private var shown = listOf<PL>()
    private val sel = mutableSetOf<String>()
    private val imgs = mutableMapOf<String, Bitmap>()
    private var done = ""

    private lateinit var frame: FrameLayout
    private lateinit var status: TextView
    private lateinit var panel: LinearLayout
    private lateinit var stSp: TextView
    private lateinit var stG: TextView
    private lateinit var btnGo: Button
    private var overlay: View? = null
    private var web: WebView? = null

    private val bgColor = Color.parseColor("#0B0B2E")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    // Optional: Wenn beim Bauen eine Spotify-Client-ID mitgegeben wurde, wird der offizielle Spotify-Login benutzt
    private fun spId() = BuildConfig.SP_ID.trim()

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f, m: Int = 0) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(m, m, m, m) }

    private fun pill(t: String, color: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(Color.parseColor(color)); cornerRadius = dp(28).toFloat() }
        setOnClickListener { f() }
    }

    private fun tile(name: String, kind: Int, c1: String, c2: String, txt: String, sub: TextView, f: () -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply { cornerRadius = dp(24).toFloat() }
            addView(LogoView(context, kind), LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(8) })
            addView(TextView(context).apply {
                text = name; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; setTextColor(Color.parseColor(txt))
            })
            sub.text = "Tippen zum Verbinden"; sub.textSize = 12f
            sub.gravity = Gravity.CENTER; sub.setTextColor(Color.parseColor(txt))
            addView(sub)
            setOnClickListener { f() }
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(48), dp(16), dp(24)) }
        root.addView(TextView(this).apply {
            text = "TuneSwap"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "Verbinde deine Musikdienste:"; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#B8B8D8")); setPadding(0, 0, 0, dp(20))
        })
        stSp = TextView(this); stG = TextView(this)
        val row = LinearLayout(this)
        row.addView(tile("Spotify", 0, "#FFFFFF", "#E6E6E6", "#1DB954", stSp) {
            if (spTok != null) loadSpotify() else loginSpotify() }, lp(0, dp(130), 1f, dp(6)))
        row.addView(tile("YouTube Music", 1, "#FF6B9A", "#D63D6E", "#FFFFFF", stG) {
            if (ytCookie != null) loadYt() else loginYt() }, lp(0, dp(130), 1f, dp(6)))
        root.addView(row)
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#B8B8D8")); setPadding(dp(6), dp(16), dp(6), dp(8)); setTextIsSelectable(true)
        }
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(status)
        root.addView(panel)
        frame = FrameLayout(this)
        frame.addView(ScrollView(this).apply { background = GlowBackground(); addView(root) })
        setContentView(frame)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (overlay != null) dropWeb() else super.onBackPressed()
    }

    // ---------- Playlist-Ansicht ----------
    private fun show(items: List<PL>) = runOnUiThread {
        shown = items; sel.clear(); render()
        log(if (items.isEmpty()) "Keine Playlists gefunden" else "${items.size} Playlists – wähle aus und übertrage")
    }

    private fun updateGo() {
        if (::btnGo.isInitialized) btnGo.text = "Auswahl (${sel.size}) → ${if (src == "sp") "YouTube Music" else "Spotify"} übertragen"
    }

    private fun render() {
        panel.removeAllViews()
        if (shown.isEmpty()) return
        panel.addView(TextView(this).apply {
            text = (if (src == "sp") "Spotify" else "YouTube Music") + " – Wiedergabelisten"
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            setPadding(dp(6), dp(16), 0, dp(8))
        })
        panel.addView(pill("Alle auswählen", "#2A2A5E") {
            if (sel.size == shown.size) sel.clear() else sel.addAll(shown.map { it.id })
            render()
        }, lp(MATCH, WRAP, 0f, dp(4)))
        btnGo = pill("", "#6C2BFF") { transfer() }
        updateGo()
        panel.addView(btnGo, lp(MATCH, WRAP, 0f, dp(4)))
        for (p in shown) panel.addView(row(p), lp(MATCH, WRAP, 0f, dp(4)))
    }

    private fun row(p: PL): LinearLayout {
        val cb = CheckBox(this).apply {
            isChecked = p.id in sel; isClickable = false; isFocusable = false
            buttonTintList = ColorStateList.valueOf(Color.WHITE)
        }
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#2A2A5E"))
        }
        val cached = imgs[p.id]
        if (cached != null) iv.setImageBitmap(cached)
        else if (!p.img.isNullOrEmpty()) Thread {
            try {
                val bm = BitmapFactory.decodeStream(URL(p.img).openStream())
                if (bm != null) { imgs[p.id] = bm; runOnUiThread { iv.setImageBitmap(bm) } }
            } catch (e: Exception) { }
        }.start()
        val tx = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply {
                text = p.name; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            })
            addView(TextView(context).apply {
                text = if (p.count > 0) "${p.count} Lieder" else "Playlist"
                textSize = 13f; setTextColor(Color.parseColor("#B8B8D8"))
            })
        }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply { setColor(Color.parseColor("#1B1B4F")); cornerRadius = dp(14).toFloat() }
            addView(cb)
            addView(iv, lp(dp(56), dp(56), 0f, dp(8)))
            addView(tx, lp(0, WRAP, 1f))
            setOnClickListener {
                if (p.id in sel) sel.remove(p.id) else sel.add(p.id)
                cb.isChecked = p.id in sel; updateGo()
            }
        }
    }

    // ---------- Anmelde-Fenster in der App ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun showWeb(url: String, desktop: Boolean, client: WebViewClient) {
        runOnUiThread {
            dropWeb()
            val wv = WebView(this)
            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                // "wv" im Browser-Namen entfernen, sonst lehnt Google die Anmeldung ab
                val def = userAgentString
                userAgentString = if (desktop)
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
                else def.replace("; wv", "").replace("Version/4.0 ", "")
            }
            if (!desktop) ytUa = wv.settings.userAgentString
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
            wv.webViewClient = client
            val bar = TextView(this).apply {
                text = "✕  Schließen"; textSize = 16f; setTextColor(Color.WHITE)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                setOnClickListener { dropWeb() }
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(bgColor)
                setPadding(0, dp(28), 0, 0)
                addView(bar, lp(WRAP, WRAP))
                addView(wv, LinearLayout.LayoutParams(MATCH, 0, 1f))
            }
            web = wv; overlay = box
            frame.addView(box, FrameLayout.LayoutParams(MATCH, MATCH))
            wv.loadUrl(url)
        }
    }

    private fun dropWeb() {
        overlay?.let { frame.removeView(it) }
        web?.stopLoading()
        web?.destroy()
        web = null; overlay = null
    }

    private fun closeWeb() { frame.post { dropWeb() } }

    // ---------- Login Spotify ----------
    private fun verifier(): String {
        val b = ByteArray(48); SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
    private fun challenge(v: String) = Base64.encodeToString(
        MessageDigest.getInstance("SHA-256").digest(v.toByteArray()),
        Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun loginSpotify() {
        if (spId().isEmpty()) return loginSpotifyWeb()
        // Offizieller Login (nur wenn der Build eine Spotify-Client-ID enthält)
        spVerifier = verifier()
        val u = "https://accounts.spotify.com/authorize?response_type=code&client_id=${spId()}" +
                "&redirect_uri=${enc(spRedirect)}&code_challenge_method=S256&code_challenge=${challenge(spVerifier)}" +
                "&scope=${enc("playlist-read-private playlist-modify-private playlist-modify-public")}"
        val colors = CustomTabColorSchemeParams.Builder().setToolbarColor(bgColor).build()
        CustomTabsIntent.Builder().setDefaultColorSchemeParams(colors).setShowTitle(true).build()
            .launchUrl(this, Uri.parse(u))
    }

    // Ohne Client-ID: Anmeldung auf Spotifys Seite, der Zugangsschlüssel wird aus den Anfragen des Web-Players gelesen
    private fun loginSpotifyWeb() {
        log("Melde dich bei Spotify an…")
        showWeb("https://accounts.spotify.com/de/login?continue=" + enc("https://open.spotify.com/"), true,
            object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    if (spTok == null && request.url.host?.endsWith("spotify.com") == true) {
                        val h = request.requestHeaders.entries
                            .firstOrNull { it.key.equals("authorization", true) }?.value
                        if (h != null && h.startsWith("Bearer ") && h.length > 60) {
                            spTok = h.removePrefix("Bearer ").trim()
                            runOnUiThread { stSp.text = "Verbunden ✓" }
                            closeWeb()
                            loadSpotify()
                        }
                    }
                    return null
                }
            })
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        val d = i.data ?: return
        val code = d.getQueryParameter("code") ?: return log("Login abgebrochen: ${d.getQueryParameter("error")}")
        bg {
            val r = http("POST", "https://accounts.spotify.com/api/token", null,
                "grant_type=authorization_code&code=${enc(code)}&redirect_uri=${enc(spRedirect)}" +
                        "&client_id=${spId()}&code_verifier=$spVerifier", true)
            spTok = r.getString("access_token")
            runOnUiThread { stSp.text = "Verbunden ✓" }
            loadSpotify()
        }
    }

    // ---------- Login YouTube Music ----------
    private fun hasSapisid(ck: String) =
        ck.split(";").map { it.trim() }.any { it.startsWith("SAPISID=") || it.startsWith("__Secure-3PAPISID=") }

    private fun loginYt() {
        log("Melde dich bei Google an…")
        showWeb("https://accounts.google.com/ServiceLogin?service=youtube&continue=" + enc("https://music.youtube.com/"), false,
            object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    if (ytCookie != null || Uri.parse(url).host != "music.youtube.com") return
                    val ck = CookieManager.getInstance().getCookie("https://music.youtube.com") ?: return
                    if (hasSapisid(ck)) {
                        ytCookie = ck
                        stG.text = "Verbunden ✓"
                        closeWeb()
                        loadYt()
                    }
                }
            })
    }

    // ---------- YouTube Music: Zugriff ----------
    private fun findAll(n: Any?, key: String, out: MutableList<JSONObject> = mutableListOf()): MutableList<JSONObject> {
        when (n) {
            is JSONObject -> {
                val ks = n.keys()
                while (ks.hasNext()) {
                    val k = ks.next(); val v = n.opt(k)
                    if (k == key && v is JSONObject) out += v else findAll(v, key, out)
                }
            }
            is JSONArray -> for (i in 0 until n.length()) findAll(n.opt(i), key, out)
        }
        return out
    }

    private fun findStr(n: Any?, key: String): String? {
        when (n) {
            is JSONObject -> {
                val ks = n.keys()
                while (ks.hasNext()) {
                    val k = ks.next(); val v = n.opt(k)
                    if (k == key && v is String) return v
                    val r = findStr(v, key)
                    if (r != null) return r
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = findStr(n.opt(i), key)
                if (r != null) return r
            }
        }
        return null
    }

    private fun contToken(r: Any?): String? =
        findAll(r, "nextContinuationData").firstOrNull()?.optString("continuation")?.ifEmpty { null }
            ?: findAll(r, "continuationCommand").firstOrNull()?.optString("token")?.ifEmpty { null }

    private fun runsText(o: JSONObject?): String {
        val a = o?.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until a.length()) sb.append(a.optJSONObject(i)?.optString("text") ?: "")
        return sb.toString()
    }

    private fun flexText(o: JSONObject, i: Int): String =
        o.optJSONArray("flexColumns")?.optJSONObject(i)?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
            ?.optJSONObject("text")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: ""

    private fun yt(path: String, body: JSONObject): JSONObject {
        val ck = ytCookie ?: throw Exception("YouTube Music ist nicht verbunden")
        val sapisid = ck.split(";").map { it.trim() }
            .firstOrNull { it.startsWith("SAPISID=") || it.startsWith("__Secure-3PAPISID=") }
            ?.substringAfter("=") ?: throw Exception("Kein Login-Cookie gefunden – bitte YouTube Music neu antippen")
        val origin = "https://music.youtube.com"
        val ts = System.currentTimeMillis() / 1000
        val hash = MessageDigest.getInstance("SHA-1").digest("$ts $sapisid $origin".toByteArray())
            .joinToString("") { "%02x".format(it) }
        val fmt = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        body.put("context", JSONObject().put("client", JSONObject()
            .put("clientName", "WEB_REMIX").put("clientVersion", "1.${fmt.format(Date())}.01.00").put("hl", "de")))
        val c = URL("$origin/youtubei/v1/$path?alt=json&key=AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000; c.readTimeout = 30000
        c.setRequestProperty("Cookie", ck)
        c.setRequestProperty("Authorization", "SAPISIDHASH ${ts}_$hash")
        c.setRequestProperty("Origin", origin)
        c.setRequestProperty("X-Origin", origin)
        c.setRequestProperty("Referer", "$origin/")
        c.setRequestProperty("X-Goog-AuthUser", "0")
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("User-Agent", ytUa.ifBlank {
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36" })
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code == 401 || code == 403) throw Exception("HTTP $code – YouTube-Sitzung ungültig, bitte YouTube Music neu antippen")
        if (code >= 400) throw Exception("HTTP $code: ${text.take(200)}")
        return if (text.isBlank()) JSONObject() else JSONObject(text)
    }

    private fun ytSearch(q: String): String? {
        for (params in listOf<String?>("EgWKAQIIAWoMEA4QChADEAQQCRAF", null)) {
            val b = JSONObject().put("query", q)
            if (params != null) b.put("params", params)
            val r = try { yt("search", b) } catch (e: Exception) {
                if (params == null || (e.message ?: "").contains("HTTP 401") || (e.message ?: "").contains("HTTP 403")) throw e
                continue
            }
            for (o in findAll(r, "musicResponsiveListItemRenderer")) {
                val v = o.optJSONObject("playlistItemData")?.optString("videoId")?.ifEmpty { null } ?: findStr(o, "videoId")
                if (v != null) return v
            }
        }
        return null
    }

    // ---------- Playlists laden ----------
    private fun loadSpotify() {
        val t = spTok ?: return
        bg {
            log("Lade Spotify-Playlists…")
            val out = mutableListOf<PL>()
            var url = "https://api.spotify.com/v1/me/playlists?limit=50"
            var more = true
            while (more) {
                val r = http("GET", url, t)
                val a = r.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val o = a.optJSONObject(i) ?: continue
                    val cnt = o.optJSONObject("tracks")?.optInt("total", 0)
                        ?: o.optJSONObject("items")?.optInt("total", 0) ?: 0
                    val img = o.optJSONArray("images")?.optJSONObject(0)?.optString("url")
                    out += PL(o.getString("id"), o.getString("name"), cnt, img)
                }
                url = if (r.isNull("next")) "" else r.getString("next")
                more = url.isNotEmpty()
            }
            src = "sp"; show(out)
        }
    }

    private fun loadYt() {
        if (ytCookie == null) return
        bg {
            log("Lade YouTube-Playlists…")
            val out = mutableListOf(PL("LM", "Gefällt mir (Liked Music)", 0, null))
            val seen = mutableSetOf("LM")
            var body = JSONObject().put("browseId", "FEmusic_liked_playlists")
            var pages = 0
            while (pages++ < 30) {
                val r = yt("browse", body)
                for (o in findAll(r, "musicTwoRowItemRenderer")) {
                    val bid = o.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")
                        ?.optString("browseId") ?: findStr(o, "browseId") ?: continue
                    if (!bid.startsWith("VL")) continue
                    val id = bid.removePrefix("VL")
                    if (!seen.add(id)) continue
                    val title = o.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: continue
                    val cnt = Regex("(\\d+)").find(runsText(o.optJSONObject("subtitle")))?.value?.toIntOrNull() ?: 0
                    val img = o.optJSONObject("thumbnailRenderer")?.optJSONObject("musicThumbnailRenderer")
                        ?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")?.optJSONObject(0)?.optString("url")
                    out += PL(id, title, cnt, img)
                }
                val tok = contToken(r) ?: break
                body = JSONObject().put("continuation", tok)
            }
            src = "yt"; show(out)
        }
    }

    // ---------- Übertragen ----------
    private fun lg(m: String) = log(done + m)

    private fun transfer() {
        val chosen = shown.filter { it.id in sel }
        if (chosen.isEmpty()) return log("Wähle erst Playlists aus")
        val s = spTok
        if (s == null || ytCookie == null) return log("Verbinde zuerst beide Dienste (Spotify und YouTube Music)")
        bg {
            done = ""
            for ((i, p) in chosen.withIndex()) {
                lg("Playlist ${i + 1}/${chosen.size}: ${p.name}")
                val ok = try {
                    if (src == "sp") spToYt(p.id, p.name, s) else ytToSp(p.id, p.name, s)
                } catch (e: Exception) { done += "✗ ${p.name}: ${e.message}\n"; false }
                if (!ok) break
            }
            lg("Fertig.")
        }
    }

    private fun spToYt(id: String, name: String, s: String): Boolean {
        val tracks = mutableListOf<String>()
        var url = "https://api.spotify.com/v1/playlists/$id/tracks?limit=100"
        var first = true
        var more = true
        while (more) {
            val r = try { http("GET", url, s) } catch (e: Exception) {
                if (first) { url = "https://api.spotify.com/v1/playlists/$id/items?limit=100"; http("GET", url, s) } else throw e
            }
            first = false
            val a = r.getJSONArray("items")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val t = o.optJSONObject("track") ?: o.optJSONObject("item") ?: continue
                val title = t.optString("name")
                val artist = t.optJSONArray("artists")?.optJSONObject(0)?.optString("name") ?: ""
                if (title.isNotBlank()) tracks += "$title $artist".trim()
            }
            url = if (r.isNull("next")) "" else r.getString("next")
            more = url.isNotEmpty()
        }
        val vids = mutableListOf<String>()
        for ((n, q) in tracks.withIndex()) {
            val v = try { ytSearch(q) } catch (e: Exception) {
                if ((e.message ?: "").contains("HTTP 40")) throw e else null
            }
            if (v != null) vids += v
            lg("${n + 1}/${tracks.size}: $q")
        }
        if (vids.isEmpty()) { done += "✗ $name: nichts gefunden (0/${tracks.size})\n"; return true }
        val created = yt("playlist/create", JSONObject()
            .put("title", "$name (von Spotify)").put("description", "Übertragen mit TuneSwap")
            .put("privacyStatus", "PRIVATE").put("videoIds", JSONArray(vids.take(100))))
        val plId = created.optString("playlistId")
        if (plId.isEmpty()) throw Exception("Playlist konnte auf YouTube Music nicht erstellt werden")
        for (ch in vids.drop(100).chunked(100)) {
            val actions = JSONArray()
            for (v in ch) actions.put(JSONObject().put("action", "ACTION_ADD_VIDEO")
                .put("addedVideoId", v).put("dedupeOption", "DEDUPE_OPTION_SKIP"))
            yt("browse/edit_playlist", JSONObject().put("playlistId", plId).put("actions", actions))
        }
        done += "✓ $name: ${vids.size}/${tracks.size} übertragen\n"
        return true
    }

    private fun spSearch(q: String, s: String): String? {
        repeat(2) {
            try {
                val items = http("GET", "https://api.spotify.com/v1/search?type=track&limit=1&q=${enc(q)}", s)
                    .getJSONObject("tracks").getJSONArray("items")
                return if (items.length() > 0) items.getJSONObject(0).getString("uri") else null
            } catch (e: Exception) {
                val m = e.message ?: ""
                if (m.contains("HTTP 429")) Thread.sleep(3000)
                else if (m.contains("HTTP 401") || m.contains("HTTP 403")) throw e
                else return null
            }
        }
        return null
    }

    private fun ytToSp(id: String, name: String, s: String): Boolean {
        val queries = mutableListOf<String>()
        var body = JSONObject().put("browseId", "VL$id")
        var pages = 0
        while (pages++ < 100) {
            val r = yt("browse", body)
            // Auf der ersten Seite nur die eigentliche Titelliste lesen (nicht die Empfehlungen darunter)
            val scope: Any = if (pages == 1) (findAll(r, "musicPlaylistShelfRenderer").firstOrNull() ?: r) else r
            for (o in findAll(scope, "musicResponsiveListItemRenderer")) {
                if (findStr(o, "videoId") == null) continue
                val t = flexText(o, 0)
                if (t.isEmpty()) continue
                queries += (t + " " + flexText(o, 1)).trim()
            }
            val tok = contToken(scope) ?: break
            body = JSONObject().put("continuation", tok)
        }
        val uris = mutableListOf<String>()
        for ((n, q) in queries.withIndex()) {
            val u = spSearch(q, s)
            if (u != null) uris += u
            lg("Suche ${n + 1}/${queries.size}: $q")
        }
        if (uris.isEmpty()) { done += "✗ $name: nichts gefunden (0/${queries.size})\n"; return true }
        val pl = http("POST", "https://api.spotify.com/v1/me/playlists", s,
            JSONObject().put("name", "$name (von YT Music)").put("public", false).toString()).getString("id")
        uris.chunked(100).forEach { ch ->
            val b = JSONObject().put("uris", JSONArray(ch)).toString()
            try { http("POST", "https://api.spotify.com/v1/playlists/$pl/tracks", s, b) }
            catch (e: Exception) { http("POST", "https://api.spotify.com/v1/playlists/$pl/items", s, b) }
        }
        done += "✓ $name: ${uris.size}/${queries.size} übertragen\n"
        return true
    }

    // ---------- Helfer ----------
    private fun bg(f: () -> Unit) = Thread {
        try { f() } catch (e: Exception) { log("Fehler: ${e.message}") }
    }.start()

    private fun log(m: String) = runOnUiThread { status.text = m }

    private fun http(method: String, url: String, token: String?, body: String? = null, form: Boolean = false): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", if (form) "application/x-www-form-urlencoded" else "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code == 401 && token != null) {
            spTok = null
            throw Exception("HTTP 401 – Spotify-Sitzung abgelaufen, bitte die Spotify-Kachel neu antippen")
        }
        if (code >= 400) throw Exception("HTTP $code: ${text.take(200)}")
        return if (text.isBlank()) JSONObject() else JSONObject(text)
    }
}

class LogoView(c: Context, private val kind: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f
        p.style = Paint.Style.FILL
        if (kind == 0) {
            p.color = Color.parseColor("#1DB954"); cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeCap = Paint.Cap.ROUND
            fun arc(x1: Float, y1: Float, qx: Float, qy: Float, x2: Float, y2: Float, w: Float) {
                p.strokeWidth = w * r
                cv.drawPath(Path().apply { moveTo(cx + x1 * r, cy + y1 * r); quadTo(cx + qx * r, cy + qy * r, cx + x2 * r, cy + y2 * r) }, p)
            }
            arc(-0.55f, -0.28f, 0.05f, -0.52f, 0.55f, -0.12f, 0.15f)
            arc(-0.45f, 0.02f, 0.05f, -0.18f, 0.45f, 0.12f, 0.12f)
            arc(-0.35f, 0.30f, 0.05f, 0.15f, 0.35f, 0.35f, 0.10f)
        } else {
            p.color = Color.parseColor("#F0453A"); cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 0.09f * r
            cv.drawCircle(cx, cy, 0.62f * r, p)
            p.style = Paint.Style.FILL
            cv.drawPath(Path().apply {
                moveTo(cx - 0.18f * r, cy - 0.3f * r); lineTo(cx - 0.18f * r, cy + 0.3f * r)
                lineTo(cx + 0.32f * r, cy); close()
            }, p)
        }
    }
}

// Hintergrund: dunkles Blau mit sanftem Violett in der Mitte und drei weichen Farbschimmern
class GlowBackground : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat(); val h = bounds.height().toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(Color.parseColor("#0B0B2E"), Color.parseColor("#241066"), Color.parseColor("#0B0B2E")),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        glow(c, w * 0.12f, h * 0.10f, w * 0.80f, "#1DB954", 60)
        glow(c, w * 0.95f, h * 0.42f, w * 0.85f, "#FF4F8B", 55)
        glow(c, w * 0.10f, h * 0.75f, w * 0.85f, "#6C2BFF", 70)
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, col: String, a: Int) {
        val base = Color.parseColor(col)
        p.shader = RadialGradient(x, y, r,
            Color.argb(a, Color.red(base), Color.green(base), Color.blue(base)),
            Color.argb(0, Color.red(base), Color.green(base), Color.blue(base)),
            Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
