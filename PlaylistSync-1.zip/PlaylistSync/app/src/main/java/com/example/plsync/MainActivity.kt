package com.example.plsync

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

class MainActivity : Activity() {
    private val spRedirect = "ytsync://spotify"

    private var spTok: String? = null
    private var gTok: String? = null
    private var spVerifier = ""

    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var etSp: EditText
    private lateinit var etG: EditText
    private lateinit var etGs: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("keys", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32) }
        fun field(hint: String, key: String) = EditText(this).apply {
            this.hint = hint; isSingleLine = true; setText(prefs.getString(key, ""))
        }.also { root.addView(it) }
        etSp = field("Spotify Client ID", "sp")
        etG = field("Google Client ID", "g")
        etGs = field("Google Client Secret", "gs")
        fun save() = prefs.edit().putString("sp", etSp.text.toString().trim())
            .putString("g", etG.text.toString().trim()).putString("gs", etGs.text.toString().trim()).apply()
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { save(); f() } }.also { root.addView(it) }
        btn("1. Mit Spotify verbinden") { loginSpotify() }
        btn("2. Mit YouTube Music verbinden") { loginGoogle() }
        btn("Spotify → YT Music (Playlist wählen)") { loadSpotifyLists() }
        btn("YT Music → Spotify (Playlist wählen)") { loadYtLists() }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(this).apply { setPadding(0, 24, 0, 24); setTextIsSelectable(true) }
        root.addView(status)
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    // ---------- Login ----------
    private fun verifier(): String {
        val b = ByteArray(48); SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
    private fun challenge(v: String) = Base64.encodeToString(
        MessageDigest.getInstance("SHA-256").digest(v.toByteArray()),
        Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun spId() = etSp.text.toString().trim()

    private fun loginSpotify() {
        if (spId().isEmpty()) return log("Spotify Client ID eingeben")
        spVerifier = verifier()
        val u = "https://accounts.spotify.com/authorize?response_type=code&client_id=${spId()}" +
                "&redirect_uri=${enc(spRedirect)}&code_challenge_method=S256&code_challenge=${challenge(spVerifier)}" +
                "&scope=${enc("playlist-read-private playlist-modify-private playlist-modify-public")}"
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        val d = i.data ?: return
        val code = d.getQueryParameter("code") ?: return log("Login abgebrochen: ${d.getQueryParameter("error")}")
        bg {
            val r = http("POST", "https://accounts.spotify.com/api/token", null,
                "grant_type=authorization_code&code=${enc(code)}&redirect_uri=${enc(spRedirect)}" +
                        "&client_id=${spId()}&code_verifier=$spVerifier", true)
            spTok = r.getString("access_token")
            log("Spotify verbunden ✓")
        }
    }

    // Google: Geräte-Login (Code auf google.com/device eingeben)
    private fun loginGoogle() {
        val gid = etG.text.toString().trim(); val sec = etGs.text.toString().trim()
        if (gid.isEmpty() || sec.isEmpty()) return log("Google Client ID und Secret eingeben")
        bg {
            val r = http("POST", "https://oauth2.googleapis.com/device/code", null,
                "client_id=${enc(gid)}&scope=${enc("https://www.googleapis.com/auth/youtube")}", true)
            val user = r.getString("user_code"); val dev = r.getString("device_code")
            val url = r.getString("verification_url"); var wait = r.optInt("interval", 5)
            runOnUiThread {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("code", user))
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
            log("Gib auf $url diesen Code ein:\n\n$user\n\n(Code ist kopiert.) Danach hierher zurück und kurz warten…")
            val end = System.currentTimeMillis() + r.optInt("expires_in", 1800) * 1000L
            while (System.currentTimeMillis() < end) {
                Thread.sleep(wait * 1000L)
                try {
                    val t = http("POST", "https://oauth2.googleapis.com/token", null,
                        "client_id=${enc(gid)}&client_secret=${enc(sec)}&device_code=${enc(dev)}" +
                                "&grant_type=${enc("urn:ietf:params:oauth:grant-type:device_code")}", true)
                    gTok = t.getString("access_token")
                    log("YouTube verbunden ✓")
                    return@bg
                } catch (e: Exception) {
                    val m = e.message ?: ""
                    if (m.contains("slow_down")) wait += 5
                    else if (!m.contains("authorization_pending")) throw e
                }
            }
            log("Zeit abgelaufen, bitte nochmal versuchen")
        }
    }

    // ---------- Playlists anzeigen ----------
    private fun loadSpotifyLists() {
        val t = spTok ?: return log("Erst mit Spotify verbinden")
        bg {
            val items = http("GET", "https://api.spotify.com/v1/me/playlists?limit=50", t).getJSONArray("items")
            showLists(items) { it.getString("name") to it.getString("id") } { id, name -> spToYt(id, name) }
        }
    }

    private fun loadYtLists() {
        val t = gTok ?: return log("Erst mit YouTube verbinden")
        bg {
            val items = http("GET", "https://www.googleapis.com/youtube/v3/playlists?part=snippet&mine=true&maxResults=50", t)
                .getJSONArray("items")
            showLists(items) { it.getJSONObject("snippet").getString("title") to it.getString("id") } { id, name -> ytToSp(id, name) }
        }
    }

    private fun showLists(a: JSONArray, f: (JSONObject) -> Pair<String, String>, click: (String, String) -> Unit) {
        runOnUiThread {
            list.removeAllViews()
            for (i in 0 until a.length()) {
                val (name, id) = f(a.getJSONObject(i))
                list.addView(Button(this).apply { text = name; setOnClickListener { click(id, name) } })
            }
        }
    }

    // ---------- Spotify -> YouTube Music ----------
    private fun spToYt(id: String, name: String) {
        val s = spTok; val g = gTok
        if (s == null || g == null) return log("Beide Konten verbinden!")
        bg {
            val tracks = mutableListOf<String>()
            var url: String? = "https://api.spotify.com/v1/playlists/$id/tracks?limit=100"
            while (url != null) {
                val r = http("GET", url, s)
                val a = r.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val t = a.getJSONObject(i).optJSONObject("track") ?: continue
                    tracks += t.getString("name") + " " + t.getJSONArray("artists").getJSONObject(0).getString("name")
                }
                url = if (r.isNull("next")) null else r.getString("next")
            }
            log("${tracks.size} Songs gefunden. Erstelle YT-Playlist…")
            val pl = http("POST", "https://www.googleapis.com/youtube/v3/playlists?part=snippet,status", g,
                JSONObject().put("snippet", JSONObject().put("title", "$name (von Spotify)"))
                    .put("status", JSONObject().put("privacyStatus", "private")).toString()).getString("id")
            var ok = 0
            for ((n, q) in tracks.withIndex()) {
                try {
                    val items = http("GET", "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video" +
                            "&videoCategoryId=10&maxResults=1&q=${enc(q)}", g).getJSONArray("items")
                    if (items.length() == 0) { log("✗ nicht gefunden: $q"); continue }
                    val vid = items.getJSONObject(0).getJSONObject("id").getString("videoId")
                    http("POST", "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet", g,
                        JSONObject().put("snippet", JSONObject().put("playlistId", pl)
                            .put("resourceId", JSONObject().put("kind", "youtube#video").put("videoId", vid))).toString())
                    ok++; log("✓ ${n + 1}/${tracks.size}: $q")
                } catch (e: Exception) {
                    log("Abbruch bei '$q': ${e.message}\n(Evtl. YouTube-Tageslimit erreicht – morgen weitermachen)")
                    return@bg
                }
            }
            log("Fertig: $ok von ${tracks.size} übertragen.")
        }
    }

    // ---------- YouTube Music -> Spotify ----------
    private fun ytToSp(id: String, name: String) {
        val s = spTok; val g = gTok
        if (s == null || g == null) return log("Beide Konten verbinden!")
        bg {
            val queries = mutableListOf<String>()
            var page = ""
            do {
                val r = http("GET", "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50" +
                        "&playlistId=$id$page", g)
                val a = r.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val sn = a.getJSONObject(i).getJSONObject("snippet")
                    val title = sn.getString("title")
                    if (title == "Deleted video" || title == "Private video") continue
                    val clean = title.replace(Regex("\\(.*?\\)|\\[.*?]|(?i)official.*|(?i)ft\\..*|(?i)feat\\..*"), "").trim()
                    val artist = sn.optString("videoOwnerChannelTitle").removeSuffix(" - Topic")
                    queries += "$clean $artist"
                }
                page = if (r.has("nextPageToken")) "&pageToken=" + r.getString("nextPageToken") else ""
            } while (page.isNotEmpty())
            log("${queries.size} Songs gefunden. Suche bei Spotify…")
            val uris = mutableListOf<String>()
            for ((n, q) in queries.withIndex()) {
                val items = http("GET", "https://api.spotify.com/v1/search?type=track&limit=1&q=${enc(q)}", s)
                    .getJSONObject("tracks").getJSONArray("items")
                if (items.length() == 0) log("✗ nicht gefunden: $q")
                else { uris += items.getJSONObject(0).getString("uri"); log("✓ ${n + 1}/${queries.size}: $q") }
            }
            val pl = http("POST", "https://api.spotify.com/v1/me/playlists", s,
                JSONObject().put("name", "$name (von YT Music)").put("public", false).toString()).getString("id")
            uris.chunked(100).forEach {
                http("POST", "https://api.spotify.com/v1/playlists/$pl/tracks", s,
                    JSONObject().put("uris", JSONArray(it)).toString())
            }
            log("Fertig: ${uris.size} von ${queries.size} übertragen.")
        }
    }

    // ---------- Helfer ----------
    private fun bg(f: () -> Unit) = Thread {
        try { f() } catch (e: Exception) { log("Fehler: ${e.message}") }
    }.start()

    private fun log(m: String) = runOnUiThread { status.text = m }

    private fun http(method: String, url: String, token: String?, body: String? = null, form: Boolean = false): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", if (form) "application/x-www-form-urlencoded" else "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code >= 400) throw Exception("HTTP $code: ${text.take(200)}")
        return if (text.isBlank()) JSONObject() else JSONObject(text)
    }
}
