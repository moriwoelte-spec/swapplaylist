Client IDs werden jetzt in der App eingegeben (und gespeichert).
Spotify: App mit Redirect URI ytsync://spotify, Web API, Konto unter User Management.
Google: YouTube Data API v3 aktivieren, Zustimmungsbildschirm mit dir als Testnutzer,
OAuth-Client-ID vom Typ "TV und Geräte mit eingeschränkter Eingabe" -> Client ID + Secret.
