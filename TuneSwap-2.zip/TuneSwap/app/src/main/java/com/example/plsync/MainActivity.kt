package com.example.plsync

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Base64
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

data class PL(val id: String, val name: String, val count: Int, val img: String?, val sub: String = "")

// Ein Lied aus der Quell-Playlist. target = ID im Zieldienst (YouTube videoId oder Spotify-URI), null = nicht gefunden
class Trk(val title: String, val artist: String, val durSec: Int, val img: String?) {
    @Volatile var target: String? = null
    @Volatile var mTitle = ""     // Titel des gefundenen Treffers
    @Volatile var mArtist = ""    // Künstler des gefundenen Treffers
    var ignored = false
}

class Cand(val id: String, val title: String, val artist: String, val dur: Int)

// kind: 0 = Playlist, 1 = Alben, 2 = Lieder, 3 = Künstler
class RJob(val pl: PL, val tracks: List<Trk>, val fromSp: Boolean, val kind: Int = 0)

// Anmeldung ungültig / abgelaufen: bricht alles ab, statt hunderte Fehler zu erzeugen
class AuthEx(m: String) : Exception(m)

class Resp(val code: Int, val text: String, val retryAfter: Int)

class MainActivity : Activity() {
    private val spRedirect = "ytsync://spotify"
    @Volatile private var spTok: String? = null
    @Volatile private var spRefresh: String? = null
    @Volatile private var spStale = false
    @Volatile private var ytCookie: String? = null
    @Volatile private var ytUa = ""
    private var spVerifier = ""
    private var src = ""
    private var shown = listOf<PL>()
    private val sel = mutableSetOf<String>()
    private val imgs = LruCache<String, Bitmap>(150)
    @Volatile private var done = ""
    private val spLock = Any()

    // Die Lieder werden nacheinander gesucht; der Pool dient nur für "Erneut abgleichen"
    private val pool: ExecutorService = Executors.newFixedThreadPool(2)
    private val imgPool: ExecutorService = Executors.newFixedThreadPool(3)
    private val queue = ArrayDeque<PL>()
    private val retrying = mutableSetOf<Trk>()
    private var rjob: RJob? = null

    private lateinit var prefs: SharedPreferences
    private lateinit var frame: FrameLayout
    private lateinit var scroll: ScrollView
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var stSp: TextView
    private lateinit var stG: TextView
    private lateinit var btnGo: Button
    private lateinit var banner: LinearLayout
    private lateinit var bTitle: TextView
    private lateinit var bText: TextView
    private lateinit var bBar: ProgBar
    private lateinit var bPct: TextView
    private var overlay: View? = null
    private var review: View? = null
    private var reviewCol: LinearLayout? = null
    private var web: WebView? = null
    private val lastUi = AtomicLong(0)

    // Playlist-Bildschirm (öffnet beim Antippen einer verbundenen Kachel)
    private var plView: View? = null
    private var plCol: LinearLayout? = null
    private var plInfo: TextView? = null
    private var query = ""
    private var tab = 0
    private var tabViews = listOf<TextView>()
    private val tabNames = listOf("Wiedergabelisten", "Alben", "Lieder", "Künstler")

    // Bremse für Spotify: Abstand zwischen Anfragen und gemeinsame Pause bei HTTP 429
    private val spGateLock = Any()
    private val spPause = AtomicLong(0)
    private val spLast = AtomicLong(0)
    @Volatile private var spGap = 250L
    @Volatile private var bannerOn = false
    @Volatile private var lastPct = 0

    private val bgColor = Color.parseColor("#0B0B2E")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    // Optional: Wenn beim Bauen eine Spotify-Client-ID mitgegeben wurde, wird der offizielle Spotify-Login benutzt
    private fun spId() = BuildConfig.SP_ID.trim()

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f, m: Int = 0) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(m, m, m, m) }

    private fun rounded(color: String, r: Int) =
        GradientDrawable().apply { setColor(Color.parseColor(color)); cornerRadius = dp(r).toFloat() }

    private fun pill(t: String, color: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE)
        background = rounded(color, 28)
        setOnClickListener { f() }
    }

    private fun tile(name: String, kind: Int, c1: String, c2: String, txt: String, sub: TextView, f: () -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply { cornerRadius = dp(24).toFloat() }
            addView(LogoView(context, kind), LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(8) })
            addView(TextView(context).apply {
                text = name; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; setTextColor(Color.parseColor(txt))
            })
            sub.textSize = 12f
            sub.gravity = Gravity.CENTER; sub.setTextColor(Color.parseColor(txt))
            addView(sub)
            setOnClickListener { f() }
            setOnLongClickListener { askDisconnect(); true }
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        prefs = getSharedPreferences("tuneswap", Context.MODE_PRIVATE)
        restoreLogins()

        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(48), dp(16), dp(24)) }
        root.addView(TextView(this).apply {
            text = "TuneSwap"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "Verbinde deine Musikdienste:"; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#B8B8D8")); setPadding(0, 0, 0, dp(20))
        })
        stSp = TextView(this); stG = TextView(this)
        val row = LinearLayout(this)
        row.addView(tile("Spotify", 0, "#FFFFFF", "#E6E6E6", "#1DB954", stSp) {
            if (spConnected()) openPlaylists("sp") else loginSpotify() }, lp(0, dp(130), 1f, dp(6)))
        row.addView(tile("YouTube Music", 1, "#FF6B9A", "#D63D6E", "#FFFFFF", stG) {
            if (ytCookie != null) openPlaylists("yt") else loginYt() }, lp(0, dp(130), 1f, dp(6)))
        root.addView(row)
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#B8B8D8")); setPadding(dp(6), dp(16), dp(6), dp(8)); setTextIsSelectable(true)
        }
        root.addView(status)
        frame = FrameLayout(this)
        scroll = ScrollView(this).apply { background = GlowBackground(); addView(root) }
        frame.addView(scroll)
        buildBanner()
        setContentView(frame)
        updateTiles()
    }

    override fun onResume() {
        super.onResume()
        kick()
    }

    override fun onPause() {
        super.onPause()
        try { CookieManager.getInstance().flush() } catch (e: Exception) { }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            review != null -> cancelReview()
            plView != null -> dropPl()
            overlay != null -> dropWeb()
            else -> super.onBackPressed()
        }
    }

    // ---------- Gespeicherte Anmeldung ----------
    private fun restoreLogins() {
        val t = prefs.getString("sp_tok", null)
        val ts = prefs.getLong("sp_tok_t", 0L)
        // Der Web-Player-Schlüssel hält ca. eine Stunde; danach holt die App sich still einen neuen
        if (t != null && System.currentTimeMillis() - ts < 50 * 60 * 1000L) spTok = t
        spRefresh = prefs.getString("sp_ref", null)
        ytUa = prefs.getString("yt_ua", "") ?: ""
        val live = try { CookieManager.getInstance().getCookie("https://music.youtube.com") } catch (e: Exception) { null }
        ytCookie = if (live != null && hasSapisid(live)) live else prefs.getString("yt_cookie", null)
    }

    private fun spConnected(): Boolean {
        if (spStale) return false
        if (spTok != null || spRefresh != null) return true
        val ck = try { CookieManager.getInstance().getCookie("https://open.spotify.com") } catch (e: Exception) { null }
        return ck != null && ck.contains("sp_dc=")
    }

    private fun setSpTok(t: String?, refresh: String? = null) {
        spTok = t
        if (refresh != null) spRefresh = refresh
        if (t != null) spStale = false
        prefs.edit().putString("sp_tok", t).putString("sp_ref", spRefresh)
            .putLong("sp_tok_t", System.currentTimeMillis()).apply()
        try { CookieManager.getInstance().flush() } catch (e: Exception) { }
        runOnUiThread { updateTiles() }
    }

    private fun saveYt(ck: String?) {
        ytCookie = ck
        prefs.edit().putString("yt_cookie", ck).putString("yt_ua", ytUa).apply()
        try { CookieManager.getInstance().flush() } catch (e: Exception) { }
        runOnUiThread { updateTiles() }
    }

    private fun updateTiles() {
        stSp.text = if (spConnected()) "Verbunden ✓" else "Tippen zum Verbinden"
        stG.text = if (ytCookie != null) "Verbunden ✓" else "Tippen zum Verbinden"
    }

    private fun askDisconnect() {
        AlertDialog.Builder(this).setTitle("Verbindungen trennen?")
            .setMessage("Spotify und YouTube Music werden abgemeldet.")
            .setPositiveButton("Trennen") { _, _ -> disconnectAll() }
            .setNegativeButton("Abbrechen", null).show()
    }

    private fun disconnectAll() {
        spTok = null; spRefresh = null; spStale = false; ytCookie = null
        prefs.edit().clear().apply()
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
        } catch (e: Exception) { }
        dropPl(); shown = emptyList(); sel.clear(); updateTiles()
        log("Verbindungen getrennt")
    }

    // Manche Handys zeichnen die Liste erst nach einer Berührung neu – darum wird nach dem Laden ein Neuzeichnen erzwungen
    private fun kick() {
        val r = Runnable {
            try { root.requestLayout(); scroll.requestLayout(); root.invalidate(); scroll.invalidate(); frame.invalidate() }
            catch (e: Exception) { }
        }
        scroll.post(r); scroll.postDelayed(r, 300); scroll.postDelayed(r, 1000)
    }

    // ---------- Fortschrittsleiste oben ----------
    private fun buildBanner() {
        bTitle = TextView(this).apply { textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        bText = TextView(this).apply {
            textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#FFD60A"))
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        bBar = ProgBar(this)
        bPct = TextView(this).apply {
            textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor("#FFD60A")); gravity = Gravity.END
        }
        val barRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
            addView(bBar, LinearLayout.LayoutParams(0, dp(6), 1f).apply { rightMargin = dp(12) })
            addView(bPct, LinearLayout.LayoutParams(dp(48), WRAP))
        }
        val outer = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#9B5CFF"), Color.parseColor("#FF4F8B"))).apply { cornerRadius = dp(22).toFloat() }
        val inner = rounded("#12124A", 20)
        val bg = LayerDrawable(arrayOf<Drawable>(outer, inner)).apply { setLayerInset(1, dp(2), dp(2), dp(2), dp(2)) }
        banner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(18), dp(14), dp(14), dp(14))
            elevation = dp(8).toFloat()
            visibility = View.GONE
            addView(bTitle); addView(bText); addView(barRow)
        }
        frame.addView(banner, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { setMargins(dp(12), dp(8), dp(12), 0) })
    }

    private fun showBanner(title: String, text: String, pct: Int) = runOnUiThread {
        lastPct = pct; bannerOn = true
        bTitle.text = title; bText.text = text; bBar.pct = pct; bPct.text = "$pct%"
        if (banner.visibility != View.VISIBLE) { banner.visibility = View.VISIBLE; banner.bringToFront() }
    }

    private fun hideBanner() = runOnUiThread { bannerOn = false; banner.visibility = View.GONE }

    private fun addOverlay(v: View) {
        frame.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        banner.bringToFront()
    }

    // ---------- Playlist-Bildschirm ----------
    private fun loadImg(iv: ImageView, url: String?) {
        if (url.isNullOrEmpty()) return
        val c = imgs.get(url)
        if (c != null) { iv.setImageBitmap(c); return }
        imgPool.execute {
            try {
                val bm = URL(url).openStream().use { BitmapFactory.decodeStream(it) }
                if (bm != null) { imgs.put(url, bm); runOnUiThread { iv.setImageBitmap(bm) } }
            } catch (e: Exception) { }
        }
    }

    // Tippen auf eine verbundene Kachel öffnet die Playlists dieses Dienstes
    private fun openPlaylists(s: String) {
        src = s; tab = 0; shown = emptyList(); sel.clear(); query = ""
        buildPlScreen()
        if (s == "sp") loadSpotify() else loadYt()
    }

    private fun buildPlScreen() {
        dropPl()
        val name = if (src == "sp") "Spotify" else "YouTube Music"
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(4), dp(14), dp(12)) }
        val sv = ScrollView(this).apply { addView(col) }
        val back = TextView(this).apply {
            text = "←"; textSize = 26f; setTextColor(Color.WHITE)
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { dropPl() }
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(12), dp(8), dp(12))
            setBackgroundColor(Color.parseColor("#0E0E3A"))
            addView(back)
            addView(TextView(context).apply {
                text = name; textSize = 20f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(View(context), LinearLayout.LayoutParams(dp(40), dp(1)))
        }
        val tabRow = LinearLayout(this).apply { setPadding(dp(8), dp(2), dp(8), dp(2)) }
        tabViews = tabNames.mapIndexed { i, n ->
            TextView(this).apply {
                text = n; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
                setPadding(dp(16), dp(9), dp(16), dp(9)); maxLines = 1
                setOnClickListener { selectTab(i) }
            }.also { tabRow.addView(it, lp(WRAP, WRAP, 0f, dp(2))) }
        }
        val tabs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(tabRow) }
        val all = TextView(this).apply {
            text = "Alle auswählen"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            setPadding(dp(18), dp(14), dp(18), dp(10))
            setOnClickListener { toggleAll() }
        }
        val search = EditText(this).apply {
            hint = "Suche"; setHintTextColor(Color.parseColor("#9A9AC8")); setTextColor(Color.WHITE); textSize = 17f
            setSingleLine(true)
            background = rounded("#22225E", 22)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; renderPl() }
            })
        }
        val info = TextView(this).apply {
            textSize = 14f; setTextColor(Color.parseColor("#B8B8D8")); setPadding(dp(18), dp(10), dp(18), dp(6))
            text = "Lade Playlists…"
        }
        btnGo = pill("", "#6C2BFF") { transfer() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0C0C33"))
            addView(bar)
            addView(tabs)
            addView(all)
            addView(search, lp(MATCH, WRAP, 0f, dp(14)))
            addView(info)
            addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
            addView(btnGo, lp(MATCH, WRAP, 0f, dp(12)))
        }
        plView = box; plCol = col; plInfo = info
        addOverlay(box)
        styleTabs()
        updateGo()
    }

    private fun dropPl() {
        plView?.let { frame.removeView(it) }
        plView = null; plCol = null; plInfo = null
        kick()
    }

    private fun visiblePl(): List<PL> {
        val q = norm(query.trim())
        return if (q.isEmpty()) shown else shown.filter { norm(it.name).contains(q) }
    }

    private fun toggleAll() {
        val ids = visiblePl().map { it.id }
        if (ids.isNotEmpty() && ids.all { it in sel }) sel.removeAll(ids.toSet()) else sel.addAll(ids)
        renderPl()
    }

    private fun renderPl() {
        val col = plCol ?: return
        col.removeAllViews()
        for (p in visiblePl()) col.addView(row(p), lp(MATCH, WRAP, 0f, dp(4)))
        updateGo()
    }

    private fun styleTabs() {
        tabViews.forEachIndexed { i, v -> v.background = if (i == tab) rounded("#2A2A5E", 14) else null }
    }

    private fun selectTab(i: Int) {
        if (plView == null || (i == tab && shown.isNotEmpty())) return
        tab = i; shown = emptyList(); sel.clear(); renderPl(); styleTabs()
        log("Lade ${tabNames[i]}…")
        if (i == 0) { if (src == "sp") loadSpotify() else loadYt() } else loadLib(src, i)
    }

    private fun show(items: List<PL>, s: String, tb: Int = 0) = runOnUiThread {
        if (plView == null || src != s || tab != tb) return@runOnUiThread
        shown = items; sel.clear(); renderPl()
        val what = when (tb) { 1 -> "Alben"; 2 -> "Lieder"; 3 -> "Künstler"; else -> "Playlists" }
        log(if (items.isEmpty()) "Keine $what gefunden" else "${items.size} $what – wähle aus und übertrage")
    }

    private fun updateGo() {
        if (::btnGo.isInitialized) btnGo.text = "Auswahl (${sel.size}) → ${if (src == "sp") "YouTube Music" else "Spotify"} übertragen"
    }

    private fun row(p: PL): LinearLayout {
        val cb = CheckBox(this).apply {
            isChecked = p.id in sel; isClickable = false; isFocusable = false
            buttonTintList = ColorStateList.valueOf(Color.WHITE)
        }
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#2A2A5E"))
        }
        loadImg(iv, p.img)
        val tx = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply {
                text = p.name; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            })
            addView(TextView(context).apply {
                text = when (tab) {
                    1 -> p.sub
                    2 -> (p.sub + (if (p.count > 0) " · " + fmtDur(p.count) else "")).trim()
                    3 -> "Künstler"
                    else -> if (p.count > 0) "${p.count} Lieder" else "Playlist"
                }
                textSize = 13f; setTextColor(Color.parseColor("#B8B8D8"))
            })
        }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded("#1B1B4F", 14)
            addView(cb)
            addView(iv, lp(dp(56), dp(56), 0f, dp(8)))
            addView(tx, lp(0, WRAP, 1f))
            setOnClickListener {
                if (p.id in sel) sel.remove(p.id) else sel.add(p.id)
                cb.isChecked = p.id in sel; updateGo()
            }
        }
    }

    // ---------- Anmelde-Fenster in der App ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWebView(desktop: Boolean): WebView {
        val wv = WebView(this)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // "wv" im Browser-Namen entfernen, sonst lehnt Google die Anmeldung ab
            val def = userAgentString
            userAgentString = if (desktop)
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
            else def.replace("; wv", "").replace("Version/4.0 ", "")
        }
        if (!desktop) ytUa = wv.settings.userAgentString
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        return wv
    }

    private fun showWeb(url: String, desktop: Boolean, client: WebViewClient) {
        runOnUiThread {
            dropWeb()
            val wv = makeWebView(desktop)
            wv.webViewClient = client
            val bar = TextView(this).apply {
                text = "✕  Schließen"; textSize = 16f; setTextColor(Color.WHITE)
                setPadding(dp(16), dp(10), dp(16), dp(10))
                setOnClickListener { dropWeb() }
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(bgColor)
                setPadding(0, dp(28), 0, 0)
                addView(bar, lp(WRAP, WRAP))
                addView(wv, LinearLayout.LayoutParams(MATCH, 0, 1f))
            }
            web = wv; overlay = box
            addOverlay(box)
            wv.loadUrl(url)
        }
    }

    private fun dropWeb() {
        overlay?.let { frame.removeView(it) }
        web?.stopLoading()
        web?.destroy()
        web = null; overlay = null
        kick()
    }

    private fun closeWeb() { frame.post { dropWeb() } }

    // ---------- Login Spotify ----------
    private fun verifier(): String {
        val b = ByteArray(48); SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
    private fun challenge(v: String) = Base64.encodeToString(
        MessageDigest.getInstance("SHA-256").digest(v.toByteArray()),
        Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun loginSpotify() {
        if (spId().isEmpty()) return loginSpotifyWeb()
        // Offizieller Login (nur wenn der Build eine Spotify-Client-ID enthält)
        spVerifier = verifier()
        val u = "https://accounts.spotify.com/authorize?response_type=code&client_id=${spId()}" +
                "&redirect_uri=${enc(spRedirect)}&code_challenge_method=S256&code_challenge=${challenge(spVerifier)}" +
                "&scope=${enc("playlist-read-private playlist-modify-private playlist-modify-public")}"
        val colors = CustomTabColorSchemeParams.Builder().setToolbarColor(bgColor).build()
        CustomTabsIntent.Builder().setDefaultColorSchemeParams(colors).setShowTitle(true).build()
            .launchUrl(this, Uri.parse(u))
    }

    // Liest den Zugangsschlüssel aus den Anfragen des Spotify-Web-Players mit
    private fun spWebClient(onTok: () -> Unit) = object : WebViewClient() {
        private val got = AtomicBoolean(false)
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            if (!got.get() && request.url.host?.endsWith("spotify.com") == true) {
                val h = request.requestHeaders.entries
                    .firstOrNull { it.key.equals("authorization", true) }?.value
                if (h != null && h.startsWith("Bearer ") && h.length > 60 && got.compareAndSet(false, true)) {
                    setSpTok(h.removePrefix("Bearer ").trim())
                    onTok()
                }
            }
            return null
        }
    }

    private fun loginSpotifyWeb() {
        log("Melde dich bei Spotify an…")
        showWeb("https://accounts.spotify.com/de/login?continue=" + enc("https://open.spotify.com/"), true,
            spWebClient { closeWeb(); log("Spotify verbunden ✓ – tippe auf die Kachel, um deine Playlists zu sehen") })
    }

    // Holt im Hintergrund (unsichtbar) einen neuen Schlüssel, solange die Spotify-Anmeldung noch gespeichert ist
    private fun silentSpotify(finished: () -> Unit) {
        val wv = makeWebView(true)
        val ended = AtomicBoolean(false)
        val end = {
            if (ended.compareAndSet(false, true)) runOnUiThread {
                try { frame.removeView(wv); wv.stopLoading(); wv.destroy() } catch (e: Exception) { }
                finished()
            }
        }
        wv.webViewClient = spWebClient { end() }
        wv.alpha = 0f
        frame.addView(wv, FrameLayout.LayoutParams(1, 1))
        wv.loadUrl("https://open.spotify.com/")
        wv.postDelayed({ end() }, 20000)
    }

    private fun refreshSpotifyBlocking(): Boolean = synchronized(spLock) {
        if (spTok != null) {
            true
        } else {
            var ok = false
            val rt = spRefresh
            if (spId().isNotEmpty() && rt != null) {
                try {
                    val r = rawHttp("POST", "https://accounts.spotify.com/api/token", emptyMap(),
                        "grant_type=refresh_token&refresh_token=${enc(rt)}&client_id=${spId()}",
                        "application/x-www-form-urlencoded")
                    if (r.code == 200) {
                        val j = JSONObject(r.text)
                        setSpTok(j.getString("access_token"), j.optString("refresh_token").ifEmpty { null })
                        ok = true
                    }
                } catch (e: Exception) { }
            }
            if (!ok) {
                val latch = CountDownLatch(1)
                runOnUiThread { silentSpotify { latch.countDown() } }
                latch.await(25, TimeUnit.SECONDS)
                ok = spTok != null
            }
            if (!ok) { spStale = true; runOnUiThread { updateTiles() } }
            ok
        }
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        val d = i.data ?: return
        val code = d.getQueryParameter("code") ?: return log("Login abgebrochen: ${d.getQueryParameter("error")}")
        bg {
            val r = rawHttp("POST", "https://accounts.spotify.com/api/token", emptyMap(),
                "grant_type=authorization_code&code=${enc(code)}&redirect_uri=${enc(spRedirect)}" +
                        "&client_id=${spId()}&code_verifier=$spVerifier", "application/x-www-form-urlencoded")
            if (r.code >= 400) throw Exception("HTTP ${r.code}: ${r.text.take(200)}")
            val j = JSONObject(r.text)
            setSpTok(j.getString("access_token"), j.optString("refresh_token").ifEmpty { null })
            log("Spotify verbunden ✓ – tippe auf die Kachel, um deine Playlists zu sehen")
        }
    }

    // ---------- Login YouTube Music ----------
    private fun hasSapisid(ck: String) =
        ck.split(";").map { it.trim() }.any { it.startsWith("SAPISID=") || it.startsWith("__Secure-3PAPISID=") }

    private fun loginYt() {
        log("Melde dich bei Google an…")
        showWeb("https://accounts.google.com/ServiceLogin?service=youtube&continue=" + enc("https://music.youtube.com/"), false,
            object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    if (ytCookie != null || Uri.parse(url).host != "music.youtube.com") return
                    val ck = CookieManager.getInstance().getCookie("https://music.youtube.com") ?: return
                    if (hasSapisid(ck)) {
                        saveYt(ck)
                        closeWeb()
                        log("YouTube Music verbunden ✓ – tippe auf die Kachel, um deine Playlists zu sehen")
                    }
                }
            })
    }

    // ---------- YouTube Music: Zugriff ----------
    private fun findAll(n: Any?, key: String, out: MutableList<JSONObject> = mutableListOf()): MutableList<JSONObject> {
        when (n) {
            is JSONObject -> {
                val ks = n.keys()
                while (ks.hasNext()) {
                    val k = ks.next(); val v = n.opt(k)
                    if (k == key && v is JSONObject) out += v else findAll(v, key, out)
                }
            }
            is JSONArray -> for (i in 0 until n.length()) findAll(n.opt(i), key, out)
        }
        return out
    }

    private fun findStr(n: Any?, key: String): String? {
        when (n) {
            is JSONObject -> {
                val ks = n.keys()
                while (ks.hasNext()) {
                    val k = ks.next(); val v = n.opt(k)
                    if (k == key && v is String) return v
                    val r = findStr(v, key)
                    if (r != null) return r
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val r = findStr(n.opt(i), key)
                if (r != null) return r
            }
        }
        return null
    }

    private fun contToken(r: Any?): String? =
        findAll(r, "nextContinuationData").firstOrNull()?.optString("continuation")?.ifEmpty { null }
            ?: findAll(r, "continuationCommand").firstOrNull()?.optString("token")?.ifEmpty { null }

    private fun runsText(o: JSONObject?): String {
        val a = o?.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until a.length()) sb.append(a.optJSONObject(i)?.optString("text") ?: "")
        return sb.toString()
    }

    private fun flexText(o: JSONObject, i: Int): String =
        o.optJSONArray("flexColumns")?.optJSONObject(i)?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
            ?.optJSONObject("text")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: ""

    // Künstlername(n) aus der zweiten Spalte (alles bis zum ersten " • ")
    private fun flexArtist(o: JSONObject): String {
        val runs = o.optJSONArray("flexColumns")?.optJSONObject(1)
            ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")?.optJSONObject("text")?.optJSONArray("runs")
            ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) {
            val t = runs.optJSONObject(i)?.optString("text") ?: ""
            if (t.trim() == "•") break
            sb.append(t)
        }
        return sb.toString().trim()
    }

    private fun parseDur(s: String): Int {
        val p = s.trim().split(":").mapNotNull { it.toIntOrNull() }
        if (p.isEmpty() || p.size != s.trim().split(":").size) return 0
        return p.fold(0) { a, b -> a * 60 + b }
    }

    private fun ytItem(o: JSONObject): Trk? {
        if (findStr(o, "videoId") == null) return null
        val title = flexText(o, 0)
        if (title.isEmpty()) return null
        val dur = parseDur(o.optJSONArray("fixedColumns")?.optJSONObject(0)
            ?.optJSONObject("musicResponsiveListItemFixedColumnRenderer")?.optJSONObject("text")
            ?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: "")
        val th = o.optJSONObject("thumbnail")?.optJSONObject("musicThumbnailRenderer")
            ?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
        val img = th?.optJSONObject(if (th.length() > 1) 1 else 0)?.optString("url")
        return Trk(title, flexArtist(o), dur, img)
    }

    private fun yt(path: String, body: JSONObject): JSONObject {
        val ck = ytCookie ?: throw AuthEx("YouTube Music ist nicht verbunden")
        val sapisid = ck.split(";").map { it.trim() }
            .firstOrNull { it.startsWith("SAPISID=") || it.startsWith("__Secure-3PAPISID=") }
            ?.substringAfter("=") ?: throw AuthEx("Kein Login-Cookie gefunden – bitte YouTube Music neu antippen")
        val origin = "https://music.youtube.com"
        val ts = System.currentTimeMillis() / 1000
        val hash = MessageDigest.getInstance("SHA-1").digest("$ts $sapisid $origin".toByteArray())
            .joinToString("") { "%02x".format(it) }
        val fmt = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        body.put("context", JSONObject().put("client", JSONObject()
            .put("clientName", "WEB_REMIX").put("clientVersion", "1.${fmt.format(Date())}.01.00").put("hl", "de")))
        val h = mapOf(
            "Cookie" to ck,
            "Authorization" to "SAPISIDHASH ${ts}_$hash",
            "Origin" to origin, "X-Origin" to origin, "Referer" to "$origin/",
            "X-Goog-AuthUser" to "0",
            "User-Agent" to ytUa.ifBlank {
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36" })
        val r = rawHttp("POST", "$origin/youtubei/v1/$path?alt=json&key=AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30",
            h, body.toString(), "application/json")
        if (r.code == 401 || r.code == 403) {
            saveYt(null)
            throw AuthEx("HTTP ${r.code} – YouTube-Sitzung ungültig, bitte YouTube Music neu antippen")
        }
        if (r.code >= 400) throw Exception("HTTP ${r.code}: ${r.text.take(200)}")
        return if (r.text.isBlank()) JSONObject() else JSONObject(r.text)
    }

    // ---------- Spotify-Zugriff (mit automatischer Erneuerung des Schlüssels) ----------
    // Sorgt für Abstand zwischen den Anfragen und wartet gemeinsam, wenn Spotify "zu viele Anfragen" meldet
    private fun spGate() {
        synchronized(spGateLock) {
            val wait = maxOf(spPause.get(), spLast.get() + spGap) - System.currentTimeMillis()
            if (wait > 0) Thread.sleep(wait)
            spLast.set(System.currentTimeMillis())
        }
    }

    private fun spApi(method: String, url: String, body: String?): JSONObject {
        var refreshedOnce = false
        var attempt = 0
        while (true) {
            var tok = spTok
            if (tok == null) { refreshSpotifyBlocking(); tok = spTok }
            if (tok == null) throw AuthEx("Spotify-Sitzung abgelaufen – bitte die Spotify-Kachel antippen")
            spGate()
            val r = rawHttp(method, url, mapOf("Authorization" to "Bearer $tok"), body, "application/json")
            when {
                r.code == 401 -> {
                    if (spTok == tok) setSpTok(null)
                    if (refreshedOnce) throw AuthEx("HTTP 401 – Spotify-Sitzung abgelaufen, bitte die Spotify-Kachel antippen")
                    refreshedOnce = true
                }
                r.code == 429 -> {
                    val wait = if (r.retryAfter > 0) r.retryAfter else 3 * (attempt + 1)
                    if (wait > 90) throw AuthEx("Spotify hat die Anfragen vorübergehend gesperrt (HTTP 429). Bitte in ${(wait + 59) / 60} Min. erneut versuchen.")
                    if (++attempt > 8) throw Exception("HTTP 429 – Spotify bremst (zu viele Anfragen)")
                    spPause.set(maxOf(spPause.get(), System.currentTimeMillis() + wait * 1000L + 300))
                    spGap = minOf(1500L, spGap * 3 / 2)
                    if (bannerOn) showBanner("Spotify bremst – kurze Pause:", "noch ca. $wait Sekunden", lastPct)
                }
                r.code == 403 -> throw AuthEx("HTTP 403: ${r.text.take(150)}")
                r.code >= 400 -> throw Exception("HTTP ${r.code}: ${r.text.take(200)}")
                else -> {
                    if (spGap > 250L) spGap = maxOf(250L, spGap - 25L)
                    return if (r.text.isBlank()) JSONObject() else JSONObject(r.text)
                }
            }
        }
    }

    // ---------- Titel-Zuordnung ----------
    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    private fun toks(s: String): Set<String> =
        Regex("[\\p{L}\\p{N}]+").findAll(norm(s)).map { it.value }.toSet()

    // Entfernt Klammern, "ft. …", "Lyrics" usw. aus Titeln
    private fun clean(s: String): String {
        var t = s.replace(Regex("\\([^)]*\\)|\\[[^\\]]*\\]"), " ")
        t = t.replace(Regex("(?i)\\s(ft|feat|featuring)\\.?\\s.*$"), " ")
        t = t.replace(Regex("(?i)\\b(official\\s+(music\\s+)?(video|audio)|lyric\\s+video|music\\s+video|lyrics?)\\b"), " ")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    private fun queries(t: Trk, retry: Boolean): List<String> {
        val base = clean(t.title)
        val c = base.replace(" - ", " ").replace(Regex("\\s+"), " ").trim()
        val l = mutableListOf<String>()
        if (!retry) {
            l += "$c ${t.artist}"; l += c
        } else {
            l += c
            val parts = base.split(" - ")
            if (parts.size >= 2) { l += parts.last().trim(); l += parts.first().trim() + " " + parts.last().trim() }
            l += c.split(" ").take(4).joinToString(" ")
            l += t.title
        }
        return l.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    }

    // Wie gut passt ein Treffer zum Quell-Titel? (Anteil der Wörter des Treffer-Titels, die im Quell-Titel vorkommen)
    private fun score(srcToks: Set<String>, candTitle: String): Double {
        val c = toks(clean(candTitle).ifEmpty { candTitle })
        if (c.isEmpty()) return 0.0
        return c.count { it in srcToks }.toDouble() / c.size
    }

    // Wählt den besten Treffer: Titel muss passen, Künstler und Länge sorgen für die richtige Version
    private fun pick(t: Trk, cands: List<Cand>, thr: Double): Cand? {
        val srcAll = toks(t.title + " " + t.artist)
        var best: Cand? = null; var bestRank = -1.0
        for (c in cands) {
            val ts = score(srcAll, c.title)
            if (ts < thr) continue
            val names = c.artist.split(Regex("(?i)\\s*(,|&|\\bx\\b|\\bfeat\\.?|\\bft\\.?)\\s*")).filter { it.isNotBlank() }
            val artistScore = if (names.isEmpty()) 0.0 else names.maxOf { n ->
                val tk = toks(n)
                if (tk.isEmpty()) 0.0 else tk.count { it in srcAll }.toDouble() / tk.size
            }
            val d = if (t.durSec > 0 && c.dur > 0) Math.abs(t.durSec - c.dur) else -1
            val durBonus = when { d < 0 -> 0.0; d <= 3 -> 0.3; d <= 10 -> 0.15; else -> 0.0 }
            val rank = ts + 0.5 * artistScore + durBonus
            if (rank > bestRank) { bestRank = rank; best = c }
        }
        return best
    }

    private fun spFind(t: Trk, retry: Boolean): Cand? {
        val thr = if (retry) 0.5 else 0.6
        for (q in queries(t, retry)) {
            val items = try {
                spApi("GET", "https://api.spotify.com/v1/search?type=track&limit=8&q=${enc(q)}", null)
                    .getJSONObject("tracks").getJSONArray("items")
            } catch (e: AuthEx) { throw e } catch (e: Exception) { continue }
            val cands = ArrayList<Cand>()
            for (i in 0 until items.length()) {
                val o = items.optJSONObject(i) ?: continue
                val uri = o.optString("uri")
                if (uri.isEmpty()) continue
                val ar = o.optJSONArray("artists")
                val names = (0 until (ar?.length() ?: 0)).mapNotNull { ar?.optJSONObject(it)?.optString("name") }
                cands += Cand(uri, o.optString("name"), names.joinToString(", "), o.optInt("duration_ms", 0) / 1000)
            }
            val h = pick(t, cands, thr)
            if (h != null) return h
        }
        return null
    }

    private val ytSongs = "EgWKAQIIAWoMEA4QChADEAQQCRAF"

    // Länge steht in der Suchergebnis-Zeile meist als letztes Stück ("Song • Künstler • Album • 3:49")
    private fun ytResultDur(o: JSONObject): Int {
        val runs = o.optJSONArray("flexColumns")?.optJSONObject(1)
            ?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")?.optJSONObject("text")?.optJSONArray("runs") ?: return 0
        for (i in runs.length() - 1 downTo 0) {
            val t = runs.optJSONObject(i)?.optString("text")?.trim() ?: continue
            if (Regex("\\d+:\\d{2}(:\\d{2})?").matches(t)) return parseDur(t)
        }
        return 0
    }

    private fun ytFind(t: Trk, retry: Boolean): Cand? {
        val thr = if (retry) 0.5 else 0.6
        val modes = if (retry) listOf<String?>(ytSongs, null) else listOf<String?>(ytSongs)
        for (q in queries(t, retry)) for (m in modes) {
            val b = JSONObject().put("query", q)
            if (m != null) b.put("params", m)
            val r = try { yt("search", b) } catch (e: AuthEx) { throw e } catch (e: Exception) { continue }
            val cands = ArrayList<Cand>()
            var n = 0
            for (o in findAll(r, "musicResponsiveListItemRenderer")) {
                if (n++ >= 8) break
                val v = o.optJSONObject("playlistItemData")?.optString("videoId")?.ifEmpty { null } ?: findStr(o, "videoId")
                if (v == null) continue
                cands += Cand(v, flexText(o, 0), flexArtist(o), ytResultDur(o))
            }
            val h = pick(t, cands, thr)
            if (h != null) return h
        }
        return null
    }

    // ---------- Alben / Künstler / Lieder (Bibliothek) ----------
    private fun findStrs(n: Any?, key: String, out: MutableList<String> = mutableListOf()): MutableList<String> {
        when (n) {
            is JSONObject -> {
                val ks = n.keys()
                while (ks.hasNext()) {
                    val k = ks.next(); val v = n.opt(k)
                    if (k == key && v is String) out += v else findStrs(v, key, out)
                }
            }
            is JSONArray -> for (i in 0 until n.length()) findStrs(n.opt(i), key, out)
        }
        return out
    }

    private fun flexRun(o: JSONObject, col: Int, idx: Int): String =
        o.optJSONArray("flexColumns")?.optJSONObject(col)?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")
            ?.optJSONObject("text")?.optJSONArray("runs")?.optJSONObject(idx)?.optString("text") ?: ""

    private fun imgOf(a: JSONArray?): String? =
        a?.optJSONObject(if (a.length() > 1) 1 else 0)?.optString("url")

    private fun ytThumb(o: JSONObject): String? =
        imgOf(findAll(o, "musicThumbnailRenderer").firstOrNull()?.optJSONObject("thumbnail")?.optJSONArray("thumbnails"))

    private fun artistsOf(o: JSONObject): String {
        val ar = o.optJSONArray("artists")
        return (0 until (ar?.length() ?: 0)).mapNotNull { ar?.optJSONObject(it)?.optString("name") }.joinToString(", ")
    }

    private fun find(t: Trk, fromSp: Boolean, kind: Int, retry: Boolean): Cand? = when (kind) {
        1 -> if (fromSp) ytFindX(t, retry, "EgWKAQIYAWoMEA4QChADEAQQCRAF", 1) else spFindX(t, retry, "album")
        3 -> if (fromSp) ytFindX(t, retry, "EgWKAQIgAWoMEA4QChADEAQQCRAF", 3) else spFindX(t, retry, "artist")
        else -> if (fromSp) ytFind(t, retry) else spFind(t, retry)
    }

    private fun spFindX(t: Trk, retry: Boolean, type: String): Cand? {
        val thr = if (retry) 0.5 else 0.6
        val qs = if (type == "artist") listOf(clean(t.title).ifEmpty { t.title }, t.title).distinct() else queries(t, retry)
        for (q in qs) {
            val items = try {
                spApi("GET", "https://api.spotify.com/v1/search?type=$type&limit=8&q=${enc(q)}", null)
                    .getJSONObject(type + "s").getJSONArray("items")
            } catch (e: AuthEx) { throw e } catch (e: Exception) { continue }
            val cands = ArrayList<Cand>()
            for (i in 0 until items.length()) {
                val o = items.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (id.isEmpty()) continue
                cands += Cand(id, o.optString("name"), if (type == "album") artistsOf(o) else "", 0)
            }
            val h = pick(t, cands, thr)
            if (h != null) return h
        }
        return null
    }

    // kind 1 = Album (ID = Album-Playlist), 3 = Künstler (ID = Kanal-ID)
    private fun ytFindX(t: Trk, retry: Boolean, params: String, kind: Int): Cand? {
        val thr = if (retry) 0.5 else 0.6
        val qs = if (kind == 3) listOf(clean(t.title).ifEmpty { t.title }, t.title).distinct() else queries(t, retry)
        for (q in qs) {
            val r = try { yt("search", JSONObject().put("query", q).put("params", params)) }
            catch (e: AuthEx) { throw e } catch (e: Exception) { continue }
            val cands = ArrayList<Cand>()
            var n = 0
            for (o in findAll(r, "musicResponsiveListItemRenderer")) {
                if (n++ >= 8) break
                val title = flexText(o, 0)
                if (title.isBlank()) continue
                if (kind == 1) {
                    val id = findStrs(o, "playlistId").firstOrNull { it.startsWith("OLAK") } ?: continue
                    cands += Cand(id, title, flexRun(o, 1, 2), 0)
                } else {
                    val bid = o.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")?.optString("browseId")
                        ?.ifEmpty { null } ?: findStr(o, "browseId") ?: continue
                    if (!bid.startsWith("UC")) continue
                    cands += Cand(bid, title, "", 0)
                }
            }
            val h = pick(t, cands, thr)
            if (h != null) return h
        }
        return null
    }

    private fun loadLib(s: String, tb: Int) {
        bg {
            log("Lade ${tabNames[tb]}…")
            val out = mutableListOf<PL>()
            if (s == "sp") {
                val first = when (tb) { 1 -> "me/albums?limit=50"; 2 -> "me/tracks?limit=50"; else -> "me/following?type=artist&limit=50" }
                var url = "https://api.spotify.com/v1/$first"
                while (url.isNotEmpty()) {
                    val r = spApi("GET", url, null)
                    val box = if (tb == 3) r.getJSONObject("artists") else r
                    val a = box.getJSONArray("items")
                    for (i in 0 until a.length()) {
                        val o = a.optJSONObject(i) ?: continue
                        when (tb) {
                            1 -> {
                                val al = o.optJSONObject("album") ?: continue
                                out += PL("${out.size}:${al.optString("id")}", al.optString("name"), 0, imgOf(al.optJSONArray("images")), artistsOf(al))
                            }
                            2 -> {
                                val t = o.optJSONObject("track") ?: o.optJSONObject("item") ?: continue
                                val title = t.optString("name")
                                if (title.isBlank()) continue
                                out += PL("${out.size}:${t.optString("id")}", title, t.optInt("duration_ms", 0) / 1000,
                                    imgOf(t.optJSONObject("album")?.optJSONArray("images")), artistsOf(t))
                            }
                            else -> out += PL("${out.size}:${o.optString("id")}", o.optString("name"), 0, imgOf(o.optJSONArray("images")))
                        }
                    }
                    log("${out.size} geladen…")
                    url = if (box.isNull("next")) "" else box.getString("next")
                }
            } else {
                val bid = when (tb) { 1 -> "FEmusic_liked_albums"; 2 -> "FEmusic_liked_videos"; else -> "FEmusic_library_corpus_artists" }
                var body = JSONObject().put("browseId", bid)
                var pages = 0
                while (pages++ < 60) {
                    val r = yt("browse", body)
                    when (tb) {
                        1 -> for (o in findAll(r, "musicTwoRowItemRenderer")) {
                            val title = o.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: continue
                            val artist = runsText(o.optJSONObject("subtitle")).split(" • ").map { it.trim() }
                                .firstOrNull { it.isNotEmpty() && !Regex("(?i)album|single|ep|\\d{4}").matches(it) } ?: ""
                            out += PL("${out.size}", title, 0, ytThumb(o), artist)
                        }
                        2 -> for (o in findAll(r, "musicResponsiveListItemRenderer")) {
                            val tr = ytItem(o) ?: continue
                            out += PL("${out.size}", tr.title, tr.durSec, tr.img, tr.artist)
                        }
                        else -> for (o in findAll(r, "musicResponsiveListItemRenderer")) {
                            val name = flexText(o, 0)
                            if (name.isEmpty()) continue
                            out += PL("${out.size}", name, 0, ytThumb(o))
                        }
                    }
                    log("${out.size} geladen…")
                    val tok = contToken(r) ?: break
                    body = JSONObject().put("continuation", tok)
                }
            }
            show(out, s, tb)
        }
    }

    // Auswahl aus Alben / Lieder / Künstler: zuerst abgleichen, dann nach Bestätigung zur Bibliothek hinzufügen
    private fun transferLib(chosen: List<PL>) {
        val kind = tab
        val fromSp = src == "sp"
        val tracks = chosen.map { Trk(it.name, it.sub, if (kind == 2) it.count else 0, it.img) }
        val label = tabNames[kind]
        dropPl(); done = ""; queue.clear()
        bg {
            try {
                lg("Suche Übereinstimmungen für $label…")
                matchAll(tracks, fromSp, kind)
                hideBanner()
                runOnUiThread { showReview(RJob(PL("lib", label, 0, null), tracks, fromSp, kind)) }
            } catch (e: Exception) {
                hideBanner(); done += "✗ $label: ${e.message}\n"; log(done)
            }
        }
    }

    private fun addLib(j: RJob, ok: List<Trk>) {
        val ids = ok.mapNotNull { it.target }
        val total = ids.size
        val noun = when (j.kind) { 1 -> "Alben"; 3 -> "Künstler"; else -> "Lieder" }
        fun prog(n: Int) = showBanner("Hinzufügen:", "$n von $total $noun werden zur Bibliothek hinzugefügt", n * 100 / total)
        prog(0)
        var n = 0
        if (j.fromSp) {
            // Ziel: YouTube Music
            for (id in ids) {
                when (j.kind) {
                    1 -> yt("like/like", JSONObject().put("target", JSONObject().put("playlistId", id)))
                    3 -> yt("subscription/subscribe", JSONObject().put("channelIds", JSONArray(listOf(id))))
                    else -> yt("like/like", JSONObject().put("target", JSONObject().put("videoId", id)))
                }
                n++; prog(n)
            }
        } else {
            // Ziel: Spotify
            val path = when (j.kind) { 1 -> "me/albums"; 3 -> "me/following?type=artist"; else -> "me/tracks" }
            val size = if (j.kind == 1) 20 else 50
            for (ch in ids.chunked(size)) {
                val clean = ch.map { it.substringAfterLast(":") }
                spApi("PUT", "https://api.spotify.com/v1/$path", JSONObject().put("ids", JSONArray(clean)).toString())
                n += ch.size; prog(n)
            }
        }
    }

    // ---------- Playlists laden ----------
    private fun loadSpotify() {
        bg {
            log("Lade Spotify-Playlists…")
            val out = mutableListOf<PL>()
            var url = "https://api.spotify.com/v1/me/playlists?limit=50"
            while (url.isNotEmpty()) {
                val r = spApi("GET", url, null)
                val a = r.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val o = a.optJSONObject(i) ?: continue
                    val cnt = o.optJSONObject("tracks")?.optInt("total", 0)
                        ?: o.optJSONObject("items")?.optInt("total", 0) ?: 0
                    val img = o.optJSONArray("images")?.optJSONObject(0)?.optString("url")
                    out += PL(o.getString("id"), o.getString("name"), cnt, img)
                }
                url = if (r.isNull("next")) "" else r.getString("next")
            }
            show(out, "sp")
        }
    }

    private fun loadYt() {
        if (ytCookie == null) return
        bg {
            log("Lade YouTube-Playlists…")
            val out = mutableListOf(PL("LM", "Gefällt mir (Liked Music)", 0, null))
            val seen = mutableSetOf("LM")
            var body = JSONObject().put("browseId", "FEmusic_liked_playlists")
            var pages = 0
            while (pages++ < 30) {
                val r = yt("browse", body)
                for (o in findAll(r, "musicTwoRowItemRenderer")) {
                    val bid = o.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint")
                        ?.optString("browseId") ?: findStr(o, "browseId") ?: continue
                    if (!bid.startsWith("VL")) continue
                    val id = bid.removePrefix("VL")
                    if (!seen.add(id)) continue
                    val title = o.optJSONObject("title")?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: continue
                    val sub = runsText(o.optJSONObject("subtitle"))
                    val cnt = Regex("(\\d[\\d.]*)\\s*(Lieder|Songs|Titel|Tracks|Videos)").find(sub)?.groupValues?.get(1)
                        ?.replace(".", "")?.toIntOrNull()
                        ?: Regex("\\d+").findAll(sub).mapNotNull { it.value.toIntOrNull() }.minOrNull() ?: 0
                    val img = o.optJSONObject("thumbnailRenderer")?.optJSONObject("musicThumbnailRenderer")
                        ?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")?.optJSONObject(0)?.optString("url")
                    out += PL(id, title, cnt, img)
                }
                val tok = contToken(r) ?: break
                body = JSONObject().put("continuation", tok)
            }
            show(out, "yt")
        }
    }

    // ---------- Titel einer Playlist lesen ----------
    private fun spTracks(id: String): List<Trk> {
        val out = mutableListOf<Trk>()
        var url = "https://api.spotify.com/v1/playlists/$id/tracks?limit=100"
        var first = true
        while (url.isNotEmpty()) {
            val r = try { spApi("GET", url, null) } catch (e: Exception) {
                if (first) { url = "https://api.spotify.com/v1/playlists/$id/items?limit=100"; spApi("GET", url, null) } else throw e
            }
            first = false
            val a = r.getJSONArray("items")
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val t = o.optJSONObject("track") ?: o.optJSONObject("item") ?: continue
                val title = t.optString("name")
                if (title.isBlank()) continue
                val ar = t.optJSONArray("artists")
                val names = (0 until (ar?.length() ?: 0)).mapNotNull { ar?.optJSONObject(it)?.optString("name") }
                val im = t.optJSONObject("album")?.optJSONArray("images")
                val img = im?.optJSONObject(if (im.length() > 1) 1 else 0)?.optString("url")
                out += Trk(title, names.joinToString(", "), t.optInt("duration_ms", 0) / 1000, img)
            }
            showBanner("Lade Playlist:", "${out.size} Lieder gelesen", 0)
            url = if (r.isNull("next")) "" else r.getString("next")
        }
        return out
    }

    private fun ytTracks(id: String): List<Trk> {
        val out = mutableListOf<Trk>()
        var body = JSONObject().put("browseId", "VL$id")
        var pages = 0
        while (pages++ < 100) {
            val r = yt("browse", body)
            // Auf der ersten Seite nur die eigentliche Titelliste lesen (nicht die Empfehlungen darunter)
            val scope: Any = if (pages == 1) (findAll(r, "musicPlaylistShelfRenderer").firstOrNull() ?: r) else r
            for (o in findAll(scope, "musicResponsiveListItemRenderer")) ytItem(o)?.let { out += it }
            showBanner("Lade Playlist:", "${out.size} Lieder gelesen", 0)
            val tok = contToken(scope) ?: break
            body = JSONObject().put("continuation", tok)
        }
        return out
    }

    // ---------- Übertragen ----------
    private fun lg(m: String) = log(done + m)

    private fun transfer() {
        val chosen = shown.filter { it.id in sel }
        if (chosen.isEmpty()) return log("Wähle erst Playlists aus")
        if (!spConnected() || ytCookie == null) return log("Verbinde zuerst beide Dienste (Spotify und YouTube Music)")
        if (tab != 0) return transferLib(chosen)
        queue.clear(); queue.addAll(chosen); done = ""
        dropPl()
        nextInQueue()
    }

    // Schritt 1: Titel lesen und im Zieldienst suchen (parallel) – danach kommt die Überprüfung
    private fun nextInQueue() {
        val p = queue.removeFirstOrNull()
        if (p == null) { hideBanner(); log(done + "Fertig."); return }
        val fromSp = src == "sp"
        bg {
            try {
                lg("Lade „${p.name}“…")
                showBanner("Lade Playlist:", p.name, 0)
                val tracks = if (fromSp) spTracks(p.id) else ytTracks(p.id)
                if (tracks.isEmpty()) {
                    hideBanner(); done += "✗ ${p.name}: keine Titel gefunden\n"; nextInQueue(); return@bg
                }
                lg("Suche Übereinstimmungen für „${p.name}“…")
                matchAll(tracks, fromSp)
                hideBanner()
                runOnUiThread { showReview(RJob(p, tracks, fromSp)) }
            } catch (e: Exception) {
                hideBanner(); queue.clear()
                done += "✗ ${p.name}: ${e.message}\n"; log(done)
            }
        }
    }

    // Die Lieder werden strikt nacheinander gesucht (Banner zeigt immer das aktuelle Lied)
    private fun matchAll(tracks: List<Trk>, fromSp: Boolean, kind: Int = 0) {
        val total = tracks.size
        for ((i, t) in tracks.withIndex()) {
            val shownName = if (t.artist.isBlank()) t.title else "${t.title} – ${t.artist}"
            showBanner("Übereinstimmung wird gesucht:", shownName, i * 100 / total)
            try {
                val h = find(t, fromSp, kind, false)
                if (h != null) { t.mTitle = h.title; t.mArtist = h.artist; t.target = h.id }
            } catch (e: AuthEx) {
                throw e
            } catch (e: Exception) {
                // Titel bleibt "nicht gefunden"
            }
        }
        showBanner("Übereinstimmung wird gesucht:", "Fertig", 100)
    }

    // ---------- Überprüfungs-Bildschirm ----------
    private fun fmtDur(s: Int) = if (s <= 0) "" else "${s / 60}:${"%02d".format(s % 60)}"

    private fun showReview(j: RJob) {
        dropReview(); retrying.clear(); rjob = j
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(28)) }
        val sv = ScrollView(this).apply { addView(col) }
        val back = TextView(this).apply {
            text = "←"; textSize = 26f; setTextColor(Color.WHITE)
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener { cancelReview() }
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(12), dp(8), dp(12))
            setBackgroundColor(Color.parseColor("#0E0E3A"))
            addView(back)
            addView(TextView(context).apply {
                text = "Übereinstimmungsüberprüfung"; textSize = 19f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(View(context), LinearLayout.LayoutParams(dp(40), dp(1)))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0C0C33"))
            addView(bar)
            addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        reviewCol = col; review = box
        addOverlay(box)
        renderReview()
    }

    private fun dropReview() {
        review?.let { frame.removeView(it) }
        review = null; reviewCol = null; rjob = null
        kick()
    }

    private fun cancelReview() {
        dropReview(); queue.clear()
        log(done + "Abgebrochen.")
    }

    private fun service(kind: Int, name: String, color: String) = LinearLayout(this).apply {
        gravity = Gravity.CENTER
        addView(LogoView(context, kind), LinearLayout.LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(6) })
        addView(TextView(context).apply {
            text = name; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.parseColor(color)); maxLines = 1
        })
    }

    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t; textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
        setPadding(dp(4), dp(22), 0, dp(8))
    }

    private fun renderReview() {
        val col = reviewCol ?: return
        val j = rjob ?: return
        col.removeAllViews()
        val active = j.tracks.filter { !it.ignored }
        val failed = active.filter { it.target == null }
        val okL = active.filter { it.target != null }

        // Kopf: Richtung, Playlist-Name, Bestätigen-Knopf
        val route = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(18), dp(8), dp(18))
            background = rounded("#22225E", 20)
            val l = if (j.fromSp) service(0, "Spotify", "#1DB954") else service(1, "YouTube Music", "#FFFFFF")
            val r = if (j.fromSp) service(1, "YouTube Music", "#FFFFFF") else service(0, "Spotify", "#1DB954")
            addView(l, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(TextView(context).apply { text = "→"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(dp(44), WRAP))
            addView(r, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        val go = Button(this).apply {
            text = "Übereinstimmungen bestätigen"; isAllCaps = false; textSize = 19f
            typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            setPadding(dp(8), dp(14), dp(8), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#E81CD0"), Color.parseColor("#B020F0"))).apply { cornerRadius = dp(28).toFloat() }
            alpha = if (okL.isEmpty()) 0.5f else 1f
            setOnClickListener { confirmReview() }
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded("#14144A", 24)
            addView(route, lp(MATCH, WRAP, 0f, 0))
            addView(TextView(context).apply {
                text = j.pl.name; textSize = 19f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setPadding(0, dp(18), 0, dp(14))
            })
            addView(go, lp(MATCH, WRAP, 0f, 0))
            addView(TextView(context).apply {
                text = "TuneSwap überträgt die Musik in deine Bibliothek, sobald die Übereinstimmungen bestätigt sind."
                textSize = 13f; setTextColor(Color.parseColor("#D8D8F0")); setPadding(dp(2), dp(10), dp(2), 0)
            })
        }
        col.addView(head, lp(MATCH, WRAP, 0f, dp(2)))

        col.addView(sectionTitle("Fehlgeschlagene Übereinstimmungen (${failed.size})"))
        if (failed.isEmpty()) col.addView(TextView(this).apply {
            text = "Alle Lieder wurden gefunden ✓"; textSize = 15f; setTextColor(Color.parseColor("#B8B8D8")); setPadding(dp(4), 0, 0, dp(4))
        })
        for (t in failed) col.addView(trackCard(t, true), lp(MATCH, WRAP, 0f, dp(4)))

        col.addView(sectionTitle("Erfolgreiche Übereinstimmungen (${okL.size})"))
        for (t in okL) col.addView(trackCard(t, false), lp(MATCH, WRAP, 0f, dp(4)))
    }

    private fun smallPill(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
        minHeight = 0; minimumHeight = 0
        setPadding(dp(6), dp(10), dp(6), dp(10))
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#8C3BFF"), Color.parseColor("#6A22D8"))).apply { cornerRadius = dp(12).toFloat() }
        setOnClickListener { f() }
    }

    private fun trackCard(t: Trk, failed: Boolean): View {
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded("#2A2A5E", 10)
            clipToOutline = true
        }
        loadImg(iv, t.img)
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply {
                text = t.title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            })
            addView(TextView(context).apply {
                text = t.artist; textSize = 13f; setTextColor(Color.parseColor("#D0D0E8"))
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0)
            })
            if (!failed && t.mTitle.isNotEmpty()) addView(TextView(context).apply {
                text = "→ " + t.mTitle + (if (t.mArtist.isNotEmpty()) " · " + t.mArtist else "")
                textSize = 12f; setTextColor(Color.parseColor("#7FE0A0"))
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(3), 0, 0)
            })
        }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(iv, LinearLayout.LayoutParams(dp(76), dp(56)))
            addView(info, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(12), 0, dp(8), 0) })
            addView(TextView(context).apply { text = fmtDur(t.durSec); textSize = 15f; setTextColor(Color.WHITE) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor(if (failed) "#4A1232" else "#13234C"))
                setStroke(dp(2), Color.parseColor(if (failed) "#E0243A" else "#2FB45A"))
                cornerRadius = dp(16).toFloat()
            }
            addView(top)
            if (failed) addView(LinearLayout(context).apply {
                setPadding(0, dp(12), 0, 0)
                addView(smallPill("Ignorieren") { t.ignored = true; renderReview() },
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(0, 0, dp(6), 0) })
                addView(smallPill(if (t in retrying) "Suche…" else "Erneut abgleichen") { retryMatch(t) },
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(6), 0, 0, 0) })
            })
        }
    }

    private fun retryMatch(t: Trk) {
        val j = rjob ?: return
        if (t in retrying) return
        retrying += t; renderReview()
        pool.execute {
            var r: Cand? = null
            var err: String? = null
            try { r = find(t, j.fromSp, j.kind, true) } catch (e: Exception) { err = e.message }
            runOnUiThread {
                retrying -= t
                if (r != null) { t.mTitle = r.title; t.mArtist = r.artist; t.target = r.id }
                else Toast.makeText(this, err ?: "Immer noch nichts gefunden", Toast.LENGTH_SHORT).show()
                if (rjob === j) renderReview()
            }
        }
    }

    // ---------- Schritt 2: nach Bestätigung zur Playlist hinzufügen ----------
    private fun confirmReview() {
        val j = rjob ?: return
        val ok = j.tracks.filter { !it.ignored && it.target != null }
        if (ok.isEmpty()) { Toast.makeText(this, "Keine Übereinstimmungen zum Übertragen", Toast.LENGTH_SHORT).show(); return }
        val total = j.tracks.size
        dropReview()
        bg {
            try {
                if (j.kind != 0) addLib(j, ok) else if (j.fromSp) addToYt(j.pl.name, ok) else addToSp(j.pl.name, ok)
                done += "✓ ${j.pl.name}: ${ok.size}/$total übertragen\n"
                hideBanner(); log(done)
                nextInQueue()
            } catch (e: Exception) {
                hideBanner(); queue.clear()
                done += "✗ ${j.pl.name}: ${e.message}\n"; log(done)
            }
        }
    }

    private fun addToYt(name: String, ok: List<Trk>) {
        val ids = ok.mapNotNull { it.target }
        val total = ids.size
        fun prog(n: Int) = showBanner("Hinzufügen:", "$n von $total Lieder werden zu „$name“ hinzugefügt", n * 100 / total)
        prog(0)
        val firstChunk = ids.take(25)
        val created = yt("playlist/create", JSONObject()
            .put("title", "$name (von Spotify)").put("description", "Übertragen mit TuneSwap")
            .put("privacyStatus", "PRIVATE").put("videoIds", JSONArray(firstChunk)))
        val plId = created.optString("playlistId")
        if (plId.isEmpty()) throw Exception("Playlist konnte auf YouTube Music nicht erstellt werden")
        var n = firstChunk.size
        prog(n)
        for (ch in ids.drop(25).chunked(25)) {
            val actions = JSONArray()
            for (v in ch) actions.put(JSONObject().put("action", "ACTION_ADD_VIDEO")
                .put("addedVideoId", v).put("dedupeOption", "DEDUPE_OPTION_SKIP"))
            yt("browse/edit_playlist", JSONObject().put("playlistId", plId).put("actions", actions))
            n += ch.size
            prog(n)
        }
    }

    private fun addToSp(name: String, ok: List<Trk>) {
        val uris = ok.mapNotNull { it.target }
        val total = uris.size
        fun prog(n: Int) = showBanner("Hinzufügen:", "$n von $total Lieder werden zu „$name“ hinzugefügt", n * 100 / total)
        prog(0)
        val pl = spApi("POST", "https://api.spotify.com/v1/me/playlists",
            JSONObject().put("name", "$name (von YT Music)").put("public", false).toString()).getString("id")
        var n = 0
        for (ch in uris.chunked(50)) {
            val b = JSONObject().put("uris", JSONArray(ch)).toString()
            try { spApi("POST", "https://api.spotify.com/v1/playlists/$pl/tracks", b) }
            catch (e: Exception) { spApi("POST", "https://api.spotify.com/v1/playlists/$pl/items", b) }
            n += ch.size
            prog(n)
        }
    }

    // ---------- Helfer ----------
    private fun bg(f: () -> Unit) = Thread {
        try { f() } catch (e: Exception) { log("Fehler: ${e.message}") }
    }.start()

    private fun log(m: String) = runOnUiThread { status.text = m; plInfo?.text = m }

    private fun rawHttp(method: String, url: String, headers: Map<String, String>, body: String?, ctype: String?): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000; c.readTimeout = 30000
        for ((k, v) in headers) c.setRequestProperty(k, v)
        if (body != null) {
            c.doOutput = true
            if (ctype != null) c.setRequestProperty("Content-Type", ctype)
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        val ra = c.getHeaderField("Retry-After")?.toIntOrNull() ?: 0
        return Resp(code, text, ra)
    }
}

// Fortschrittsbalken (grau, gelbe Füllung)
class ProgBar(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var pct: Int = 0
        set(v) { field = v.coerceIn(0, 100); invalidate() }

    override fun onDraw(cv: Canvas) {
        val h = height.toFloat(); val w = width.toFloat(); val r = h / 2f
        p.color = Color.parseColor("#A8A8B8")
        cv.drawRoundRect(0f, 0f, w, h, r, r, p)
        if (pct > 0) {
            p.color = Color.parseColor("#FFD60A")
            cv.drawRoundRect(0f, 0f, maxOf(h, w * pct / 100f), h, r, r, p)
        }
    }
}

class LogoView(c: Context, private val kind: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f
        p.style = Paint.Style.FILL
        if (kind == 0) {
            p.color = Color.parseColor("#1DB954"); cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeCap = Paint.Cap.ROUND
            fun arc(x1: Float, y1: Float, qx: Float, qy: Float, x2: Float, y2: Float, w: Float) {
                p.strokeWidth = w * r
                cv.drawPath(Path().apply { moveTo(cx + x1 * r, cy + y1 * r); quadTo(cx + qx * r, cy + qy * r, cx + x2 * r, cy + y2 * r) }, p)
            }
            arc(-0.55f, -0.28f, 0.05f, -0.52f, 0.55f, -0.12f, 0.15f)
            arc(-0.45f, 0.02f, 0.05f, -0.18f, 0.45f, 0.12f, 0.12f)
            arc(-0.35f, 0.30f, 0.05f, 0.15f, 0.35f, 0.35f, 0.10f)
        } else {
            p.color = Color.parseColor("#F0453A"); cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 0.09f * r
            cv.drawCircle(cx, cy, 0.62f * r, p)
            p.style = Paint.Style.FILL
            cv.drawPath(Path().apply {
                moveTo(cx - 0.18f * r, cy - 0.3f * r); lineTo(cx - 0.18f * r, cy + 0.3f * r)
                lineTo(cx + 0.32f * r, cy); close()
            }, p)
        }
    }
}

// Hintergrund: dunkles Blau mit sanftem Violett in der Mitte und drei weichen Farbschimmern
class GlowBackground : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat(); val h = bounds.height().toFloat()
        p.shader = LinearGradient(0f, 0f, 0f, h,
            intArrayOf(Color.parseColor("#0B0B2E"), Color.parseColor("#241066"), Color.parseColor("#0B0B2E")),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        glow(c, w * 0.12f, h * 0.10f, w * 0.80f, "#1DB954", 60)
        glow(c, w * 0.95f, h * 0.42f, w * 0.85f, "#FF4F8B", 55)
        glow(c, w * 0.10f, h * 0.75f, w * 0.85f, "#6C2BFF", 70)
    }

    private fun glow(c: Canvas, x: Float, y: Float, r: Float, col: String, a: Int) {
        val base = Color.parseColor(col)
        p.shader = RadialGradient(x, y, r,
            Color.argb(a, Color.red(base), Color.green(base), Color.blue(base)),
            Color.argb(0, Color.red(base), Color.green(base), Color.blue(base)),
            Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
