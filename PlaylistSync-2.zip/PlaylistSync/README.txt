Zugangsdaten als GitHub-Secrets: SPOTIFY_ID, GOOGLE_ID, GOOGLE_SECRET
