plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Die Zugangsdaten kommen beim Bauen aus GitHub-Secrets (siehe README)
val spotifyId = System.getenv("SPOTIFY_ID") ?: ""
val googleId = System.getenv("GOOGLE_ID") ?: ""
val googleSecret = System.getenv("GOOGLE_SECRET") ?: ""

android {
    namespace = "com.example.plsync"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.plsync"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "SP_ID", "\"$spotifyId\"")
        buildConfigField("String", "G_ID", "\"$googleId\"")
        buildConfigField("String", "G_SECRET", "\"$googleSecret\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
