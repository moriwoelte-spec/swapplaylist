TuneSwap – Playlists zwischen Spotify und YouTube Music übertragen

So bekommst du die App
1. Alles aus diesem Ordner in ein GitHub-Repository hochladen (build.gradle.kts muss ganz oben liegen).
2. Unter Settings > Secrets and variables > Actions drei Secrets anlegen:
   SPOTIFY_ID, GOOGLE_ID, GOOGLE_SECRET
3. Reiter "Actions" > "TuneSwap bauen" > fertigen Lauf öffnen > unten "TuneSwap-APK" herunterladen.
   Die APK steckt in einer ZIP-Datei; entpacken und auf dem Handy installieren.

Wichtig: Secrets erst anlegen, dann bauen. Sonst steht in der App "Dieser Build enthält keine Zugangsdaten".

Spotify (einmalig)
- developer.spotify.com/dashboard > Create app
- Redirect URI:  ytsync://spotify
- Die Client ID kommt als Secret SPOTIFY_ID.
- Spotify verlangt für solche Apps seit 2026 ein Premium-Konto, eine Client ID pro Entwickler und
  nur wenige Nutzer. Dein eigenes Spotify-Konto unter "User Management" eintragen.

Google / YouTube (einmalig)
- console.cloud.google.com > neues Projekt > "YouTube Data API v3" aktivieren
- OAuth-Zustimmungsbildschirm: Extern, dein Google-Konto als Testnutzer eintragen
- Anmeldedaten > OAuth-Client-ID erstellen > Typ "Desktop-App" (NICHT "TV und Geräte")
- Client-ID = Secret GOOGLE_ID, Clientschlüssel = Secret GOOGLE_SECRET
- Im Testmodus läuft die Anmeldung nach etwa 7 Tagen ab, dann einfach neu anmelden.

Ablauf in der App
- Auf eine Kachel tippen, im Browser ganz normal anmelden, zurück zur App
  (falls sie nicht von selbst aufgeht: auf der Fertig-Seite "Zurück zu TuneSwap" tippen).
- Playlists auswählen und übertragen. YouTube erlaubt am Tag nur etwa 65 Songs.
