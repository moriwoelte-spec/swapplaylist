TuneSwap – Playlists zwischen Spotify und YouTube Music übertragen

So wird gebaut
- Diese Datei (TuneSwap.zip) liegt im Hauptordner des GitHub-Repos.
- Actions > "Build APK" > "Run workflow". Danach die APK unter "Releases" holen.

Anmelden (keine API, keine Schlüssel nötig)
- Kachel antippen, die Anmeldeseite des Dienstes geht in der App auf, normal anmelden.
- Spotify: Die App liest den Zugangsschlüssel aus dem Spotify-Web-Player mit.
- YouTube Music: Die App nutzt deine Anmeldung auf music.youtube.com.
- Beides sind inoffizielle Wege und können brechen, wenn Spotify oder Google etwas ändern.

Optional, falls Spotify per Web-Login nicht klappt (offizieller Weg)
- developer.spotify.com/dashboard > Create app (Premium nötig), Redirect URI: ytsync://spotify
- Client ID als GitHub-Secret SPOTIFY_ID anlegen, neu bauen. Dann nutzt die App den offiziellen Login.

Neu in Version 1.1
- Anmeldung bleibt gespeichert: Nach dem Neustart sind Spotify und YouTube Music weiter verbunden.
  Der Spotify-Schlüssel wird bei Bedarf automatisch im Hintergrund erneuert.
- Kachel lange gedrückt halten = beide Dienste abmelden.
- Playlists werden nach dem Laden sofort angezeigt.
- Nach "Übertragen" werden alle Lieder zuerst abgeglichen (mehrere gleichzeitig, deutlich schneller).
  Fortschrittsleiste oben zeigt den Song, der gerade gesucht wird, später das Hinzufügen.
- Überprüfungs-Bildschirm: Nicht gefundene Lieder lassen sich ignorieren oder erneut abgleichen,
  darunter stehen alle Lieder, die hinzugefügt werden. Erst "Übereinstimmungen bestätigen" legt die Playlist an.
