package com.example.plsync

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.ServerSocket
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

data class PL(val id: String, val name: String, val count: Int, val img: String?)

class MainActivity : Activity() {
    private val spRedirect = "ytsync://spotify"
    private var spTok: String? = null
    private var gTok: String? = null
    private var spVerifier = ""
    private var src = ""
    private var shown = listOf<PL>()
    private val sel = mutableSetOf<String>()
    private val imgs = mutableMapOf<String, Bitmap>()
    private var done = ""

    private lateinit var status: TextView
    private lateinit var panel: LinearLayout
    private lateinit var stSp: TextView
    private lateinit var stG: TextView
    private lateinit var btnGo: Button

    private val bgColor = Color.parseColor("#0B0B2E")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun spId() = BuildConfig.SP_ID.trim()
    private fun gId() = BuildConfig.G_ID.trim()
    private fun gSec() = BuildConfig.G_SECRET.trim()

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f, m: Int = 0) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(m, m, m, m) }

    private fun pill(t: String, color: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(Color.parseColor(color)); cornerRadius = dp(28).toFloat() }
        setOnClickListener { f() }
    }

    private fun tile(name: String, kind: Int, c1: String, c2: String, txt: String, sub: TextView, f: () -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor(c1), Color.parseColor(c2))).apply { cornerRadius = dp(24).toFloat() }
            addView(LogoView(context, kind), LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(8) })
            addView(TextView(context).apply {
                text = name; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; setTextColor(Color.parseColor(txt))
            })
            sub.text = "Tippen zum Verbinden"; sub.textSize = 12f
            sub.gravity = Gravity.CENTER; sub.setTextColor(Color.parseColor(txt))
            addView(sub)
            setOnClickListener { f() }
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(48), dp(16), dp(24)) }
        root.addView(TextView(this).apply {
            text = "TuneSwap"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "Verbinde deine Musikdienste:"; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#B8B8D8")); setPadding(0, 0, 0, dp(20))
        })
        stSp = TextView(this); stG = TextView(this)
        val row = LinearLayout(this)
        row.addView(tile("Spotify", 0, "#FFFFFF", "#E6E6E6", "#1DB954", stSp) {
            if (spTok != null) loadSpotify() else loginSpotify() }, lp(0, dp(130), 1f, dp(6)))
        row.addView(tile("YouTube Music", 1, "#FF6B9A", "#D63D6E", "#FFFFFF", stG) {
            if (gTok != null) loadYt() else loginGoogle() }, lp(0, dp(130), 1f, dp(6)))
        root.addView(row)
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#B8B8D8")); setPadding(dp(6), dp(16), dp(6), dp(8)); setTextIsSelectable(true)
        }
        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(status)
        root.addView(panel)
        setContentView(ScrollView(this).apply { setBackgroundColor(bgColor); addView(root) })
    }

    // ---------- Playlist-Ansicht ----------
    private fun show(items: List<PL>) = runOnUiThread {
        shown = items; sel.clear(); render()
        log(if (items.isEmpty()) "Keine Playlists gefunden" else "${items.size} Playlists – wähle aus und übertrage")
    }

    private fun updateGo() {
        if (::btnGo.isInitialized) btnGo.text = "Auswahl (${sel.size}) → ${if (src == "sp") "YouTube Music" else "Spotify"} übertragen"
    }

    private fun render() {
        panel.removeAllViews()
        if (shown.isEmpty()) return
        panel.addView(TextView(this).apply {
            text = (if (src == "sp") "Spotify" else "YouTube Music") + " – Wiedergabelisten"
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            setPadding(dp(6), dp(16), 0, dp(8))
        })
        panel.addView(pill("Alle auswählen", "#2A2A5E") {
            if (sel.size == shown.size) sel.clear() else sel.addAll(shown.map { it.id })
            render()
        }, lp(MATCH, WRAP, 0f, dp(4)))
        btnGo = pill("", "#6C2BFF") { transfer() }
        updateGo()
        panel.addView(btnGo, lp(MATCH, WRAP, 0f, dp(4)))
        for (p in shown) panel.addView(row(p), lp(MATCH, WRAP, 0f, dp(4)))
    }

    private fun row(p: PL): LinearLayout {
        val cb = CheckBox(this).apply {
            isChecked = p.id in sel; isClickable = false; isFocusable = false
            buttonTintList = ColorStateList.valueOf(Color.WHITE)
        }
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.parseColor("#2A2A5E"))
        }
        val cached = imgs[p.id]
        if (cached != null) iv.setImageBitmap(cached)
        else if (!p.img.isNullOrEmpty()) Thread {
            try {
                val bm = BitmapFactory.decodeStream(URL(p.img).openStream())
                if (bm != null) { imgs[p.id] = bm; runOnUiThread { iv.setImageBitmap(bm) } }
            } catch (e: Exception) { }
        }.start()
        val tx = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply {
                text = p.name; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            })
            addView(TextView(context).apply {
                text = "${p.count} Lieder"; textSize = 13f; setTextColor(Color.parseColor("#B8B8D8"))
            })
        }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply { setColor(Color.parseColor("#1B1B4F")); cornerRadius = dp(14).toFloat() }
            addView(cb)
            addView(iv, lp(dp(56), dp(56), 0f, dp(8)))
            addView(tx, lp(0, WRAP, 1f))
            setOnClickListener {
                if (p.id in sel) sel.remove(p.id) else sel.add(p.id)
                cb.isChecked = p.id in sel; updateGo()
            }
        }
    }

    // ---------- Login ----------
    private fun verifier(): String {
        val b = ByteArray(48); SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
    private fun challenge(v: String) = Base64.encodeToString(
        MessageDigest.getInstance("SHA-256").digest(v.toByteArray()),
        Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun loginSpotify() {
        if (spId().isEmpty()) return log("Dieser Build enthält keine Spotify-Zugangsdaten (siehe README)")
        spVerifier = verifier()
        val u = "https://accounts.spotify.com/authorize?response_type=code&client_id=${spId()}" +
                "&redirect_uri=${enc(spRedirect)}&code_challenge_method=S256&code_challenge=${challenge(spVerifier)}" +
                "&scope=${enc("playlist-read-private playlist-modify-private playlist-modify-public")}"
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        val d = i.data ?: return
        if (d.host == "google") return   // Rücksprung nach dem Google-Login, der Rest läuft schon im Hintergrund
        val code = d.getQueryParameter("code") ?: return log("Login abgebrochen: ${d.getQueryParameter("error")}")
        bg {
            val r = http("POST", "https://accounts.spotify.com/api/token", null,
                "grant_type=authorization_code&code=${enc(code)}&redirect_uri=${enc(spRedirect)}" +
                        "&client_id=${spId()}&code_verifier=$spVerifier", true)
            spTok = r.getString("access_token")
            runOnUiThread { stSp.text = "Verbunden ✓" }
            loadSpotify()
        }
    }

    private fun loginGoogle() {
        val gid = gId(); val sec = gSec()
        if (gid.isEmpty() || sec.isEmpty()) return log("Dieser Build enthält keine Google-Zugangsdaten (siehe README)")
        bg {
            // Normale Google-Anmeldeseite im Browser; Google schickt den Code an einen kleinen lokalen Empfänger (127.0.0.1)
            val server = ServerSocket(0, 5, InetAddress.getByName("127.0.0.1"))
            try {
                val redirect = "http://127.0.0.1:${server.localPort}"
                val ver = verifier()
                val u = "https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=${enc(gid)}" +
                        "&redirect_uri=${enc(redirect)}&code_challenge_method=S256&code_challenge=${challenge(ver)}" +
                        "&scope=${enc("https://www.googleapis.com/auth/youtube")}"
                runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
                log("Melde dich bei Google an…")
                val res = waitForGoogle(server)
                val code = res?.getQueryParameter("code")
                    ?: return@bg log("Login abgebrochen: ${res?.getQueryParameter("error")}")
                val t = http("POST", "https://oauth2.googleapis.com/token", null,
                    "client_id=${enc(gid)}&client_secret=${enc(sec)}&code=${enc(code)}" +
                            "&code_verifier=$ver&redirect_uri=${enc(redirect)}&grant_type=authorization_code", true)
                gTok = t.getString("access_token")
                runOnUiThread { stG.text = "Verbunden ✓" }
                loadYt()
            } catch (e: java.net.SocketTimeoutException) {
                log("Zeit abgelaufen, bitte nochmal versuchen")
            } finally {
                server.close()
            }
        }
    }

    // Wartet, bis Google den Browser auf 127.0.0.1 zurückschickt, und liefert die Adresse mit code= oder error=
    private fun waitForGoogle(server: ServerSocket): Uri? {
        server.soTimeout = 5 * 60 * 1000
        while (true) {
            val sock = server.accept()
            var result: Uri? = null
            sock.use {
                it.soTimeout = 5000   // Browser öffnet manchmal leere Vorab-Verbindungen
                val line = try { it.getInputStream().bufferedReader().readLine() ?: "" } catch (e: java.io.IOException) { "" }
                val path = line.split(" ").getOrNull(1) ?: "/"
                val uri = Uri.parse("http://127.0.0.1$path")
                val hit = uri.getQueryParameter("code") != null || uri.getQueryParameter("error") != null
                val html = if (hit)
                    "<html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>" +
                            "<meta http-equiv=refresh content='0;url=ytsync://google'></head>" +
                            "<body style='font-family:sans-serif;text-align:center;padding:48px 16px'>" +
                            "<h2>Fertig ✓</h2><p><a href='ytsync://google' style='font-size:22px'>Zurück zu TuneSwap</a></p></body></html>"
                else ""
                val bytes = html.toByteArray()
                val out = it.getOutputStream()
                out.write(("HTTP/1.1 ${if (hit) "200 OK" else "404 Not Found"}\r\n" +
                        "Content-Type: text/html; charset=utf-8\r\nContent-Length: ${bytes.size}\r\n" +
                        "Connection: close\r\n\r\n").toByteArray())
                out.write(bytes); out.flush()
                result = if (hit) uri else null
            }
            val r = result
            if (r != null) return r
        }
    }

    // ---------- Playlists laden ----------
    private fun loadSpotify() {
        val t = spTok ?: return
        bg {
            log("Lade Spotify-Playlists…")
            val out = mutableListOf<PL>()
            var url = "https://api.spotify.com/v1/me/playlists?limit=50"
            var more = true
            while (more) {
                val r = http("GET", url, t)
                val a = r.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val o = a.optJSONObject(i) ?: continue
                    val cnt = o.optJSONObject("tracks")?.optInt("total", 0)
                        ?: o.optJSONObject("items")?.optInt("total", 0) ?: 0
                    val img = o.optJSONArray("images")?.optJSONObject(0)?.optString("url")
                    out += PL(o.getString("id"), o.getString("name"), cnt, img)
                }
                url = if (r.isNull("next")) "" else r.getString("next")
                more = url.isNotEmpty()
            }
            src = "sp"; show(out)
        }
    }

    private fun loadYt() {
        val t = gTok ?: return
        bg {
            log("Lade YouTube-Playlists…")
            val out = mutableListOf<PL>()
            var page = ""
            do {
                val r = http("GET", "https://www.googleapis.com/youtube/v3/playlists?part=snippet,contentDetails" +
                        "&mine=true&maxResults=50$page", t)
                val a = r.getJSONArray("items")
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i); val sn = o.getJSONObject("snippet")
                    val th = sn.optJSONObject("thumbnails")
                    val img = (th?.optJSONObject("medium") ?: th?.optJSONObject("default"))?.optString("url")
                    out += PL(o.getString("id"), sn.getString("title"),
                        o.optJSONObject("contentDetails")?.optInt("itemCount", 0) ?: 0, img)
                }
                page = if (r.has("nextPageToken")) "&pageToken=" + r.getString("nextPageToken") else ""
            } while (page.isNotEmpty())
            src = "yt"; show(out)
        }
    }

    // ---------- Übertragen ----------
    private fun lg(m: String) = log(done + m)

    private fun transfer() {
        val chosen = shown.filter { it.id in sel }
        if (chosen.isEmpty()) return log("Wähle erst Playlists aus")
        val s = spTok; val g = gTok
        if (s == null || g == null) return log("Verbinde zuerst beide Dienste (Spotify und YouTube Music)")
        bg {
            done = ""
            for ((i, p) in chosen.withIndex()) {
                lg("Playlist ${i + 1}/${chosen.size}: ${p.name}")
                val ok = try {
                    if (src == "sp") spToYt(p.id, p.name, s, g) else ytToSp(p.id, p.name, s, g)
                } catch (e: Exception) { done += "✗ ${p.name}: ${e.message}\n"; false }
                if (!ok) break
            }
            lg("Fertig.")
        }
    }

    private fun spToYt(id: String, name: String, s: String, g: String): Boolean {
        val tracks = mutableListOf<String>()
        var url = "https://api.spotify.com/v1/playlists/$id/tracks?limit=100"
        var first = true
        var more = true
        while (more) {
            val r = try { http("GET", url, s) } catch (e: Exception) {
                if (first) { url = "https://api.spotify.com/v1/playlists/$id/items?limit=100"; http("GET", url, s) } else throw e
            }
            first = false
            val a = r.getJSONArray("items")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val t = o.optJSONObject("track") ?: o.optJSONObject("item") ?: continue
                tracks += t.getString("name") + " " + t.getJSONArray("artists").getJSONObject(0).getString("name")
            }
            url = if (r.isNull("next")) "" else r.getString("next")
            more = url.isNotEmpty()
        }
        val pl = http("POST", "https://www.googleapis.com/youtube/v3/playlists?part=snippet,status", g,
            JSONObject().put("snippet", JSONObject().put("title", "$name (von Spotify)"))
                .put("status", JSONObject().put("privacyStatus", "private")).toString()).getString("id")
        var ok = 0
        for ((n, q) in tracks.withIndex()) {
            try {
                val items = http("GET", "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video" +
                        "&videoCategoryId=10&maxResults=1&q=${enc(q)}", g).getJSONArray("items")
                if (items.length() == 0) continue
                val vid = items.getJSONObject(0).getJSONObject("id").getString("videoId")
                http("POST", "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet", g,
                    JSONObject().put("snippet", JSONObject().put("playlistId", pl)
                        .put("resourceId", JSONObject().put("kind", "youtube#video").put("videoId", vid))).toString())
                ok++; lg("${n + 1}/${tracks.size}: $q")
            } catch (e: Exception) {
                done += "✗ $name: Abbruch nach $ok/${tracks.size} (YouTube-Tageslimit? morgen weitermachen)\n"
                return false
            }
        }
        done += "✓ $name: $ok/${tracks.size} übertragen\n"
        return true
    }

    private fun ytToSp(id: String, name: String, s: String, g: String): Boolean {
        val queries = mutableListOf<String>()
        var page = ""
        do {
            val r = http("GET", "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50" +
                    "&playlistId=$id$page", g)
            val a = r.getJSONArray("items")
            for (i in 0 until a.length()) {
                val sn = a.getJSONObject(i).getJSONObject("snippet")
                val title = sn.getString("title")
                if (title == "Deleted video" || title == "Private video") continue
                val clean = title.replace(Regex("\\(.*?\\)|\\[.*?]|(?i)official.*|(?i)ft\\..*|(?i)feat\\..*"), "").trim()
                val artist = sn.optString("videoOwnerChannelTitle").removeSuffix(" - Topic")
                queries += "$clean $artist"
            }
            page = if (r.has("nextPageToken")) "&pageToken=" + r.getString("nextPageToken") else ""
        } while (page.isNotEmpty())
        val uris = mutableListOf<String>()
        for ((n, q) in queries.withIndex()) {
            val items = http("GET", "https://api.spotify.com/v1/search?type=track&limit=1&q=${enc(q)}", s)
                .getJSONObject("tracks").getJSONArray("items")
            if (items.length() > 0) uris += items.getJSONObject(0).getString("uri")
            lg("Suche ${n + 1}/${queries.size}: $q")
        }
        val pl = http("POST", "https://api.spotify.com/v1/me/playlists", s,
            JSONObject().put("name", "$name (von YT Music)").put("public", false).toString()).getString("id")
        uris.chunked(100).forEach { ch ->
            val body = JSONObject().put("uris", JSONArray(ch)).toString()
            try { http("POST", "https://api.spotify.com/v1/playlists/$pl/tracks", s, body) }
            catch (e: Exception) { http("POST", "https://api.spotify.com/v1/playlists/$pl/items", s, body) }
        }
        done += "✓ $name: ${uris.size}/${queries.size} übertragen\n"
        return true
    }

    // ---------- Helfer ----------
    private fun bg(f: () -> Unit) = Thread {
        try { f() } catch (e: Exception) { log("Fehler: ${e.message}") }
    }.start()

    private fun log(m: String) = runOnUiThread { status.text = m }

    private fun http(method: String, url: String, token: String?, body: String? = null, form: Boolean = false): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", if (form) "application/x-www-form-urlencoded" else "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code >= 400) throw Exception("HTTP $code: ${text.take(200)}")
        return if (text.isBlank()) JSONObject() else JSONObject(text)
    }
}

class LogoView(c: Context, private val kind: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f
        p.style = Paint.Style.FILL
        if (kind == 0) {
            p.color = Color.parseColor("#1DB954"); cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeCap = Paint.Cap.ROUND
            fun arc(x1: Float, y1: Float, qx: Float, qy: Float, x2: Float, y2: Float, w: Float) {
                p.strokeWidth = w * r
                cv.drawPath(Path().apply { moveTo(cx + x1 * r, cy + y1 * r); quadTo(cx + qx * r, cy + qy * r, cx + x2 * r, cy + y2 * r) }, p)
            }
            arc(-0.55f, -0.28f, 0.05f, -0.52f, 0.55f, -0.12f, 0.15f)
            arc(-0.45f, 0.02f, 0.05f, -0.18f, 0.45f, 0.12f, 0.12f)
            arc(-0.35f, 0.30f, 0.05f, 0.15f, 0.35f, 0.35f, 0.10f)
        } else {
            p.color = Color.parseColor("#F0453A"); cv.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 0.09f * r
            cv.drawCircle(cx, cy, 0.62f * r, p)
            p.style = Paint.Style.FILL
            cv.drawPath(Path().apply {
                moveTo(cx - 0.18f * r, cy - 0.3f * r); lineTo(cx - 0.18f * r, cy + 0.3f * r)
                lineTo(cx + 0.32f * r, cy); close()
            }, p)
        }
    }
}
