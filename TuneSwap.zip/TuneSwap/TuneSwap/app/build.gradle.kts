plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Die Zugangsdaten kommen beim Bauen aus GitHub-Secrets (siehe README)
val spotifyId = System.getenv("SPOTIFY_ID") ?: ""

android {
    namespace = "com.example.plsync"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.plsync"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
        buildConfigField("String", "SP_ID", "\"$spotifyId\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.browser:browser:1.8.0")
}
